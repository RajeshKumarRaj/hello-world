/*
 * [y] hybris Platform
 *
 * Copyright (c) 2018 SAP SE or an SAP affiliate company.  All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package bt.batelco.facades.process.email.context;

import de.hybris.platform.acceleratorservices.model.cms2.pages.EmailPageModel;
import de.hybris.platform.acceleratorservices.process.email.context.AbstractEmailContext;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commerceservices.model.process.StoreFrontCustomerProcessModel;
import de.hybris.platform.core.model.c2l.LanguageModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.exceptions.AmbiguousIdentifierException;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.media.MediaService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import javax.annotation.Resource;

import static bt.batelco.facades.constants.BatelcoFacadesConstants.CATALOG_ONLINE;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.CONTENT_CATALOG_ID;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.EMAIL_LOGO_IDENTIFIER;
import static bt.batelco.facades.constants.BatelcoFacadesConstants.TERMS_AND_CONDITIONS_MEDIA_IDENTIFIER;


/**
 * Velocity context for a customer email.
 */
public class CustomerEmailContext extends AbstractEmailContext<StoreFrontCustomerProcessModel> {

  private static final Logger LOG = LoggerFactory.getLogger(CustomerEmailContext.class);
  private static final String CONFIRMATION_ID = "confirmationId";

  @Resource(name = "catalogVersionService")
  private CatalogVersionService catalogVersionService;

  @Resource(name = "mediaService")
  private MediaService mediaService;

  private String siteLogoUrl;
  private String termsAndContionsUrl;
  private Converter<UserModel, CustomerData> customerConverter;
  private CustomerData customerData;

  @Override
  public void init(final StoreFrontCustomerProcessModel storeFrontCustomerProcessModel,
                   final EmailPageModel emailPageModel) {
    super.init(storeFrontCustomerProcessModel, emailPageModel);
    customerData = getCustomerConverter().convert(getCustomer(storeFrontCustomerProcessModel));

    final CustomerModel customerModel = getCustomer(storeFrontCustomerProcessModel);
    if (customerModel != null) {
      put(CONFIRMATION_ID, customerModel.getCustomerID());
    }

    try {
      final CatalogVersionModel
          contentCatalogOnline =
          catalogVersionService.getCatalogVersion(CONTENT_CATALOG_ID, CATALOG_ONLINE);

      final MediaModel siteLogo = mediaService.getMedia(contentCatalogOnline, EMAIL_LOGO_IDENTIFIER);
      siteLogoUrl = siteLogo.getURL2();

      final MediaModel
          termsAndContions =
          mediaService.getMedia(TERMS_AND_CONDITIONS_MEDIA_IDENTIFIER);
      termsAndContionsUrl = termsAndContions.getURL2();
    } catch (UnknownIdentifierException | AmbiguousIdentifierException ex) {
      LOG.warn(ex.getMessage());
    }
  }

  @Override
  protected BaseSiteModel getSite(final StoreFrontCustomerProcessModel storeFrontCustomerProcessModel) {
    return storeFrontCustomerProcessModel.getSite();
  }

  @Override
  protected CustomerModel getCustomer(final StoreFrontCustomerProcessModel storeFrontCustomerProcessModel) {
    return storeFrontCustomerProcessModel.getCustomer();
  }

  protected Converter<UserModel, CustomerData> getCustomerConverter() {
    return customerConverter;
  }

  @Required
  public void setCustomerConverter(final Converter<UserModel, CustomerData> customerConverter) {
    this.customerConverter = customerConverter;
  }

  public CustomerData getCustomer() {
    return customerData;
  }

  @Override
  protected LanguageModel getEmailLanguage(final StoreFrontCustomerProcessModel businessProcessModel) {
    return businessProcessModel.getLanguage();
  }

  public String getSiteLogoUrl() {
    return siteLogoUrl;
  }

  public String getTermsAndContionsUrl() {
    return termsAndContionsUrl;
  }
}
