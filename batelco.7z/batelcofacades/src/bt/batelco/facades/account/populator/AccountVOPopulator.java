package bt.batelco.facades.account.populator;

import bt.batelco.integration.bss.account.vo.AccountVO;
import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

public class AccountVOPopulator implements Populator<RegisterData, AccountVO> {

	@Override
	public void populate(RegisterData source, AccountVO target) throws ConversionException {
		target.setFirstName(source.getFirstName());
	    target.setLastName(source.getLastName());
	    target.setEmail(source.getLogin());
	    target.setCprId(source.getCprId());
	    target.setIdType(source.getIdType());
	    target.setDob(source.getDob());
	    target.setPhone(source.getPhone());
	    target.setCountry(source.getCountryCode());
	    target.setCity(source.getCity());
	    target.setFlat(source.getFlat());
	    target.setBuilding(source.getBuilding());
	    target.setBuildingName(source.getBuildingName());
	    target.setRoad(source.getRoad());
	    target.setBlock(source.getBlock());
	    //target.setAddressLine1(source.getAddressLine1());
	    //target.setAddressLine2(source.getAddressLine2());
	    target.setZipCode(source.getZipCode());
	}

}
