package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InitPaymentResponse {

	@JsonProperty("InitPaymentResult")
	InitPaymentResult InitPaymentResultObject;

	public InitPaymentResult getInitPaymentResultObject() {
		return InitPaymentResultObject;
	}

	public void setInitPaymentResultObject(InitPaymentResult initPaymentResultObject) {
		InitPaymentResultObject = initPaymentResultObject;
	}


}
