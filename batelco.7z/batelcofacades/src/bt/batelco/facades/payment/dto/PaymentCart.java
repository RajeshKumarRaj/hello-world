package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PaymentCart {

	@JsonProperty("PaymentCartItem")
	private InitPaymentCartItem[] initPaymentCartItem;

	public InitPaymentCartItem[] getInitPaymentCartItem() {
		return initPaymentCartItem;
	}

	public void setInitPaymentCartItem(InitPaymentCartItem[] initPaymentCartItem) {
		this.initPaymentCartItem = initPaymentCartItem;
	}

	
}
