package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InitPayment {

	@JsonProperty("PaymentData")
	private InitPaymentData initPaymentData;

	public InitPaymentData getInitPaymentData() {
		return initPaymentData;
	}

	public void setInitPaymentData(InitPaymentData initPaymentData) {
		this.initPaymentData = initPaymentData;
	}
	
}
