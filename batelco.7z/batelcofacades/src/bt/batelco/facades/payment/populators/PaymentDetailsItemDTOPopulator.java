package bt.batelco.facades.payment.populators;

import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import bt.batelco.facades.order.data.BatelcoPaymentInfoData;
import bt.batelco.facades.payment.dto.PaymentDetailsItemDTO;

/**
 * Populates target {@link PaymentDetailsItemDTO} data based on {@link OrderEntryData} source.
 */
public class PaymentDetailsItemDTOPopulator 

implements Populator<OrderEntryData, PaymentDetailsItemDTO> {

  @Override
  public void populate(OrderEntryData source, PaymentDetailsItemDTO target) throws ConversionException {
    final BatelcoPaymentInfoData paymentInfoData = source.getPaymentInfo();

    if (paymentInfoData != null) {
      target.setType(paymentInfoData.getServiceType());
      target.setAccountNumber(paymentInfoData.getAccountNumber());
      target.setAccountStatus(paymentInfoData.getAccountStatus());
      target.setTelNo(paymentInfoData.getServiceNumber());
      target.setTelStatus(paymentInfoData.getServiceStatus());
    }
  }
}