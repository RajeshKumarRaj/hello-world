package bt.batelco.facades.payment.populators;

import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import bt.batelco.facades.payment.data.PaymentModeData;
import bt.batelco.facades.payment.dto.PaymentCustomerDTO;
import bt.batelco.facades.payment.dto.PaymentDetailsDTO;
import bt.batelco.facades.payment.dto.PaymentDetailsItemDTO;
import bt.batelco.facades.payment.dto.PaymentProductEntryDTO;
import bt.batelco.facades.payment.dto.PaymentProductEntryPriceDTO;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Populates target {@link PaymentDetailsDTO} data from source {@link OrderData} data.
 */
public class PaymentDetailsDTOPopulator implements Populator<OrderData, PaymentDetailsDTO> {
  private static final int SCALE = 3;
  private Converter<CustomerData, PaymentCustomerDTO> paymentCustomerConverter;
  private Converter<OrderEntryData, PaymentProductEntryDTO> paymentProductDTOConverter;
  private Converter<OrderEntryData, PaymentDetailsItemDTO> paymentDetailsItemDTOConverter;

  private static final String ORDER_ENTRY_ID_SEPARATOR = ".";

  @Override
  public void populate(OrderData source, PaymentDetailsDTO target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    populatePaymentCardType(source, target);
    populatePaymentDetailsItems(source, target);
    populatePaymentDetailsTotalAmount(source, target);
    populateCustomerDTO(source, target);
  }

  private void populatePaymentCardType(final OrderData source, final PaymentDetailsDTO target) {
    final PaymentModeData paymentModeData = source.getPaymentType();
    if (paymentModeData != null) {
      target.setCardType(paymentModeData.getPaymentType());
    }
  }

  private void populatePaymentDetailsItems(final OrderData source, final PaymentDetailsDTO target) {
    final List<PaymentDetailsItemDTO> paymentDetailsItems = new ArrayList<>();
    final Map<Integer, PaymentDetailsItemDTO> groupedPaymentItems = new HashMap<>();

    final String orderId = source.getCode();
    source.getEntries().forEach(orderEntryData -> {
      if (CollectionUtils.isEmpty(orderEntryData.getEntryGroupNumbers())) {
        // create payment detail item if single product
        paymentDetailsItems.add(createPaymentDetailsItem(orderEntryData, orderId));
      } else {
        // create payment detail item for bundle scenario
        orderEntryData.getEntryGroupNumbers().forEach(entryGroupNumber -> {
          groupedPaymentItems.computeIfPresent(entryGroupNumber, (key, value) -> {
            value.getProducts().add(createPaymentProductEntryDTO(orderEntryData, orderId));
            return value;
          });

          groupedPaymentItems.computeIfAbsent(entryGroupNumber, key -> createPaymentDetailsItem(orderEntryData,
                                                                                                orderId));
        });
      }
    });

    // add grouped(bundle) payment detail items to items list
    groupedPaymentItems.forEach((key, value) -> paymentDetailsItems.add(value));
    // calculate the amount for each payment detail item
    paymentDetailsItems.forEach(paymentItem -> paymentItem.setAmount(
        String.valueOf(paymentItem.getProducts().stream().mapToDouble(this::getProductEntryDTOTotalAmount).sum())));
    target.setItems(paymentDetailsItems);
  }

  private double getProductEntryDTOTotalAmount(final PaymentProductEntryDTO paymentProductEntryDTO) {
    final PaymentProductEntryPriceDTO entryPrice = paymentProductEntryDTO.getEntryPrice();
    double[] entryPricesArray = {Double.valueOf(entryPrice.getDownpayment()), Double.valueOf(entryPrice.getAdvance()),
                                 Double.valueOf(entryPrice.getVat())};

    return Arrays.stream(entryPricesArray).sum();
  }

  private PaymentDetailsItemDTO createPaymentDetailsItem(final OrderEntryData orderEntry, final String orderId) {
    final PaymentDetailsItemDTO paymentDetailsItemDTO = paymentDetailsItemDTOConverter.convert(orderEntry);
    paymentDetailsItemDTO.setOrderId(orderId);
    paymentDetailsItemDTO.setProducts(Stream.of(createPaymentProductEntryDTO(orderEntry, orderId))
                                          .collect(Collectors.toList()));
    return paymentDetailsItemDTO;
  }

  private PaymentProductEntryDTO createPaymentProductEntryDTO(final OrderEntryData orderEntry, final String orderId) {
    final PaymentProductEntryDTO productEntryDTO = paymentProductDTOConverter.convert(orderEntry);
    // updates product entry id to match Hybris format
    productEntryDTO.setEntryId(orderId + ORDER_ENTRY_ID_SEPARATOR + productEntryDTO.getEntryId());

    return productEntryDTO;
  }

  private void populatePaymentDetailsTotalAmount(final OrderData source, final PaymentDetailsDTO target) {
    final PriceData totalAmountPrice = source.getOnlineTotalPay();
    if (totalAmountPrice == null) {
      target.setTotalAmount(calculateTotalAmount(target));
    } else {
      target.setTotalAmount(String.valueOf(totalAmountPrice.getValue()));
    }
  }

  private String calculateTotalAmount(final PaymentDetailsDTO paymentDetailsDTO) {
    final double totalItemsAmount = paymentDetailsDTO.getItems().stream()
        .mapToDouble(item -> Double.valueOf(item.getAmount())).sum();
    return String.valueOf(BigDecimal.valueOf(totalItemsAmount).setScale(SCALE, RoundingMode.DOWN));
  }

  private void populateCustomerDTO(final OrderData source, final PaymentDetailsDTO target) {
    final PaymentCustomerDTO customerDTO = paymentCustomerConverter.convert((CustomerData) source.getUser());
    final String orderCprId = source.getCprId();
    if (StringUtils.isNotEmpty(orderCprId)) {
      // sets order cpr id if configured
      customerDTO.setId(orderCprId);
    }

    target.setCustomer(customerDTO);
  }

  @Required
  public void setPaymentProductDTOConverter(
      Converter<OrderEntryData, PaymentProductEntryDTO> paymentProductDTOConverter) {
    this.paymentProductDTOConverter = paymentProductDTOConverter;
  }

  @Required
  public void setPaymentCustomerConverter(Converter<CustomerData, PaymentCustomerDTO> paymentCustomerConverter) {
    this.paymentCustomerConverter = paymentCustomerConverter;
  }

  @Required
  public void setPaymentDetailsItemDTOConverter(
      Converter<OrderEntryData, PaymentDetailsItemDTO> paymentDetailsItemDTOConverter) {
    this.paymentDetailsItemDTOConverter = paymentDetailsItemDTOConverter;
  }
}
