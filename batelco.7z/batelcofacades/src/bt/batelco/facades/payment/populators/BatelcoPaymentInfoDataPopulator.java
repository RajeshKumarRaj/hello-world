package bt.batelco.facades.payment.populators;

import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import bt.batelco.core.model.BatelcoPaymentInfoModel;
import bt.batelco.facades.order.data.BatelcoPaymentInfoData;

/**
 * Populates target {@link BatelcoPaymentInfoData} based on {@link BatelcoPaymentInfoModel} source.
 */
public class BatelcoPaymentInfoDataPopulator implements Populator<BatelcoPaymentInfoModel, BatelcoPaymentInfoData> {

  @Override
  public void populate(BatelcoPaymentInfoModel source, BatelcoPaymentInfoData target) throws ConversionException {
    target.setServiceNumber(source.getServiceNumber());
    target.setServiceType(source.getServiceType());
    target.setServiceStatus(source.getServiceStatus());
    target.setBillProfile(source.getBillProfile());
    target.setAccountNumber(source.getAccountNumber());
    target.setAccountStatus(source.getAccountStatus());
  }
}