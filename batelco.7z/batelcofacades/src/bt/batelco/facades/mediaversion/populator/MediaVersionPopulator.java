package bt.batelco.facades.mediaversion.populator;

import de.hybris.platform.cmsfacades.data.MediaData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.model.MediaVersionModel;
import bt.batelco.facades.mediaversion.data.MediaVersionData;

public class MediaVersionPopulator implements Populator<MediaVersionModel, MediaVersionData> {
  private Converter<MediaModel, MediaData> mediaModelConverter;

  @Override
  public void populate(MediaVersionModel mediaVersionModel, MediaVersionData mediaVersionData)
      throws ConversionException {

    mediaVersionData.setMedia(mediaModelConverter.convert(mediaVersionModel.getMedia()));
    mediaVersionData.setName(mediaVersionModel.getName());
    mediaVersionData.setVersion(mediaVersionModel.getVersion());
  }

  @Required
  public void setMediaModelConverter(Converter<MediaModel, MediaData> mediaModelConverter) {
    this.mediaModelConverter = mediaModelConverter;
  }
}
