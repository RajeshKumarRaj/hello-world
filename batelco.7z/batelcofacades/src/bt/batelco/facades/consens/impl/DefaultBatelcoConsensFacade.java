package bt.batelco.facades.consens.impl;

import de.hybris.platform.acceleratorservices.config.SiteConfigService;
import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.commercefacades.consent.data.ConsentTemplateData;
import de.hybris.platform.commercefacades.consent.impl.DefaultConsentFacade;
import de.hybris.platform.commerceservices.consent.exceptions.CommerceConsentGivenException;
import de.hybris.platform.commerceservices.model.consent.ConsentTemplateModel;
import de.hybris.platform.core.model.user.CustomerModel;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.consens.BatelcoConsensFacade;
import bt.batelco.facades.exception.ConsentAlreadySignedFacadeException;
import bt.batelco.facades.exception.FacadeException;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNull;

/**
 * Default implementation for {@link BatelcoConsensFacade}
 */
public class DefaultBatelcoConsensFacade extends DefaultConsentFacade implements BatelcoConsensFacade {

  private static final String BATELCO_TERMS_AND_CONDITIONS_TEMPLATE = "terms.and.conditions.consent";

  private SiteConfigService siteConfigService;

  @Override
  public void giveConsent(String consentTemplateId, Integer consentTemplateVersion, String customerUid) {

    validateParameterNotNull(consentTemplateId, "Parameter consentTemplateId must not be null");
    validateParameterNotNull(consentTemplateVersion, "Parameter consentTemplateVersion must not be null");

    CustomerModel customer = getUserService().getUserForUID(customerUid.toLowerCase().trim(), CustomerModel.class);
    final BaseSiteModel baseSite = getBaseSiteService().getCurrentBaseSite();

    final ConsentTemplateModel consentTemplate = getCommerceConsentService().getConsentTemplate(consentTemplateId,
                                                                                                consentTemplateVersion,
                                                                                                baseSite);
    try {
      getCommerceConsentService().giveConsent(customer, consentTemplate);
    } catch (CommerceConsentGivenException ex) {
      throw new ConsentAlreadySignedFacadeException("consent already given", ex);
    }
  }

  @Override
  public ConsentTemplateData getTermsAndConditionsConsentTemplateData() {
    final String consentId = siteConfigService.getProperty(BATELCO_TERMS_AND_CONDITIONS_TEMPLATE);
    if (StringUtils.isBlank(consentId)) {
      throw new FacadeException("Unknown identifier for terms and conditions");
    }
    return getLatestConsentTemplate(consentId);
  }

  @Required
  public void setSiteConfigService(SiteConfigService siteConfigService) {
    this.siteConfigService = siteConfigService;
  }
}
