package bt.batelco.facades.exception;

public class InvalidCustomerFacadeException extends FacadeException {
  public InvalidCustomerFacadeException(String message) {
    super(message);
  }

  public InvalidCustomerFacadeException(Throwable cause) {
    super(cause);
  }
}
