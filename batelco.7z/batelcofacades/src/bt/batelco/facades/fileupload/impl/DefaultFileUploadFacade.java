package bt.batelco.facades.fileupload.impl;

import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.commerceservices.util.GuidKeyGenerator;
import de.hybris.platform.core.model.media.MediaFolderModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.security.PrincipalModel;
import de.hybris.platform.order.CartService;
import de.hybris.platform.servicelayer.media.MediaService;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.user.UserService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;
import java.util.stream.Stream;

import bt.batelco.core.cart.BatelcoCartConfigService;
import bt.batelco.facades.fileupload.FileUploadFacade;

public class DefaultFileUploadFacade implements FileUploadFacade {

  private static final Logger LOG = LoggerFactory.getLogger(DefaultFileUploadFacade.class);

  private static final String FORM = "form-";
  private static final String CPR_FRONT = "cpr-front-";
  private static final String CPR_BACK = "cpr-back-";
  private static final String FRONT_SIDE = "Front side";
  private static final String BACK_SIDE = "Back side";
  private static final String PAYMENT_EVIDENCE = "payment-evidence-";
  public static final String FILE_MIME_TYPE_NOT_SUPPORTED = "File mime type not supported";

  private MediaService mediaService;
  private BatelcoCartConfigService cartConfigService;
  private CatalogVersionService catalogVersionService;
  private GuidKeyGenerator guidKeyGenerator;
  private String managerGroupId;
  private ModelService modelService;
  private CartService cartService;
  private UserService userService;

  @Override
  public void attachAcquisitionForm(MultipartFile file, InputStream inputStream, int entryNumber) {
    List<AbstractOrderEntryModel> entries = cartService.getSessionCart().getEntries();
    if (entries.size() <= entryNumber) {
      LOG.warn("Cannot attach acquisition form to entry with number {} because there are only {} entries", entryNumber,
               entries.size());
      return;
    }
    String name = FORM + guidKeyGenerator.generate().toString();
    String acceptedMimeTypes = cartConfigService.getAllAcquisitionFormMimeTypes();
    Double maxSize = cartConfigService.getAcquisitionFormMaxSize();
    String mimeType = file.getContentType();

    if (!isValidMimeType(mimeType, acceptedMimeTypes)) {
      LOG.warn("Cannot attach acquisition form to entry with number {} because file mime type {} is not supported",
               entryNumber, mimeType);
      throw new IllegalArgumentException(FILE_MIME_TYPE_NOT_SUPPORTED);
    }

    if (!isValidSize(file, maxSize)) {
      LOG.warn("Cannot attach acquisition form to entry with number {} because file exceeds max size limit of {} bytes",
               entryNumber, maxSize);
      throw new MaxUploadSizeExceededException(maxSize.longValue());
    }

    MediaFolderModel folder = mediaService.getFolder(cartConfigService.getAcquisitionFormFolderName());
    MediaModel media = createMedia(inputStream, name, mimeType, folder, file.getOriginalFilename());

    AbstractOrderEntryModel entry = entries.get(entryNumber);
    entry.setAcquisitionForm(media);

    modelService.save(entry);
  }

  private boolean isValidSize(MultipartFile file, Double maxSize) {
    return file.getSize() <= maxSize;
  }

  private boolean isValidMimeType(String mimeType, String acceptedMimeTypes) {
    return Stream.of(acceptedMimeTypes.split(","))
        .map(String::trim)
        .anyMatch(str -> str.equalsIgnoreCase(mimeType));
  }

  @Override
  public void attachCprFront(MultipartFile file, InputStream inputStream) {
    String name = CPR_FRONT + guidKeyGenerator.generate().toString();

    MediaModel media = createCprMedia(file, inputStream, name, FRONT_SIDE);

    CartModel cart = cartService.getSessionCart();
    cart.setCprFront(media);
    modelService.save(cart);
  }

  @Override
  public void attachCprBack(MultipartFile file, InputStream inputStream) {
    String name = CPR_BACK + guidKeyGenerator.generate().toString();

    MediaModel media = createCprMedia(file, inputStream, name, BACK_SIDE);

    CartModel cart = cartService.getSessionCart();
    cart.setCprBack(media);
    modelService.save(cart);
  }

  @Override
  public void attachPaymentEvidence(MultipartFile file, InputStream inputStream) {

    String name = PAYMENT_EVIDENCE + guidKeyGenerator.generate().toString();
    MediaModel media = createPaymentEvidenceMedia(file, inputStream, name);
    CartModel cart = cartService.getSessionCart();
    cart.setPaymentEvidence(media);
    modelService.save(cart);
    modelService.refresh(cart);
  }

  private MediaModel createPaymentEvidenceMedia(MultipartFile file, InputStream inputStream, String name) {
    String acceptedMimeTypes = cartConfigService.getAllPaymentEvidenceMimeTypes();
    Double maxSize = cartConfigService.getPaymentEvidenceMaxSize();
    String mimeType = file.getContentType();

    if (!isValidMimeType(mimeType, acceptedMimeTypes)) {
      LOG.warn("Cannot attach payment evidence because file mime type {} is not supported", mimeType);
      throw new IllegalArgumentException(FILE_MIME_TYPE_NOT_SUPPORTED);
    }

    if (!isValidSize(file, maxSize)) {
      LOG.warn("Cannot attach payment evidence because the file exceeds max size limit of {} bytes", maxSize);
      throw new MaxUploadSizeExceededException(maxSize.longValue());
    }

    MediaFolderModel folder = mediaService.getFolder(cartConfigService.getPaymentEvidenceFolderName());

    return createMedia(inputStream, name, mimeType, folder, file.getOriginalFilename());
  }


  private MediaModel createCprMedia(MultipartFile file, InputStream inputStream, String name, String side) {
    String acceptedMimeTypes = cartConfigService.getAllCprMimeTypes();
    Double maxSize = cartConfigService.getCprMaxSize();
    String mimeType = file.getContentType();

    if (!isValidMimeType(mimeType, acceptedMimeTypes)) {
      LOG.warn("Cannot attach CPR {} because file mime type {} is not supported", side, mimeType);
      throw new IllegalArgumentException(FILE_MIME_TYPE_NOT_SUPPORTED);
    }

    if (!isValidSize(file, maxSize)) {
      LOG.warn("Cannot attach CPR {} because the file exceeds max size limit of {} bytes", side, maxSize);
      throw new MaxUploadSizeExceededException(maxSize.longValue());
    }

    MediaFolderModel folder = mediaService.getFolder(cartConfigService.getCprFolderName());

    return createMedia(inputStream, name, mimeType, folder, file.getOriginalFilename());
  }

  private MediaModel createMedia(InputStream inputStream, String name, String mimeType, MediaFolderModel folder,
                                 String realFilename) {
    MediaModel media = modelService.create(MediaModel.class);
    media.setCode(name);
    media.setMime(mimeType);
    media.setCatalogVersion(getMediaCatalogVersion());
    modelService.save(media);

    mediaService.setStreamForMedia(media, inputStream, name, mimeType, folder);
    media.setPermittedPrincipals(getPermittedPrincipals());
    media.setRealFileName(realFilename);

    modelService.save(media);

    return media;
  }

  @Override
  public String getAllAcquisitionFormMimeTypes() {
    return cartConfigService.getAllAcquisitionFormMimeTypes();
  }

  @Override
  public String getAllCprMimeTypes() {
    return cartConfigService.getAllCprMimeTypes();
  }

  @Override
  public Double getAcquisitionFormMaxSize() {
    return cartConfigService.getAcquisitionFormMaxSize();
  }

  @Override
  public Double getCprMaxSize() {
    return cartConfigService.getCprMaxSize();
  }

  @Override
  public String getAllPaymentEvidenceMimeTypes() {
    return cartConfigService.getAllPaymentEvidenceMimeTypes();
  }

  @Override
  public Double getPaymentEvidenceMaxSize() {
    return cartConfigService.getPaymentEvidenceMaxSize();
  }

  private List<PrincipalModel> getPermittedPrincipals() {
    return org.fest.util.Collections.list(userService.getCurrentUser(),
                                          userService.getUserGroupForUID(managerGroupId));
  }

  private CatalogVersionModel getMediaCatalogVersion() {
    return catalogVersionService.getCatalogVersion(cartConfigService.getCatalogName(),
                                                   cartConfigService.getCatalogVersion());
  }

  @Required
  public void setMediaService(MediaService mediaService) {
    this.mediaService = mediaService;
  }

  @Required
  public void setCartConfigService(BatelcoCartConfigService cartConfigService) {
    this.cartConfigService = cartConfigService;
  }

  @Required
  public void setCatalogVersionService(CatalogVersionService catalogVersionService) {
    this.catalogVersionService = catalogVersionService;
  }

  @Required
  public void setGuidKeyGenerator(GuidKeyGenerator guidKeyGenerator) {
    this.guidKeyGenerator = guidKeyGenerator;
  }

  @Required
  public void setManagerGroupId(String managerGroupId) {
    this.managerGroupId = managerGroupId;
  }

  @Required
  public void setModelService(ModelService modelService) {
    this.modelService = modelService;
  }

  @Required
  public void setCartService(CartService cartService) {
    this.cartService = cartService;
  }

  @Required
  public void setUserService(UserService userService) {
    this.userService = userService;
  }
}
