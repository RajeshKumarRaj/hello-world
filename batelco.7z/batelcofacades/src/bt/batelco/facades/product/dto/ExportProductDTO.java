package bt.batelco.facades.product.dto;


import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "productId", "name", "description", "url", "imageUrl", "brandName", "condition", "stockAvailability","price","shipping"})
public class ExportProductDTO {

    private String productId;
    private String name;
    private String description;
    private String url;
    private String imageUrl;
    private String brandName;
    private String condition;
    private String stockAvailability;
    private String price;
    private Shipping shipping;

    public ExportProductDTO(){}

    @Override
    public String toString() {
        return "Product{" +
                "\n productId='" + productId + '\'' +
                "\n name='" + name + '\'' +
                //"\n summary='" + summary + '\'' +
                ",\n description='" + description + '\'' +
                "\n url='" + url + '\'' +
                ",\n imageUrl='" + imageUrl + '\'' +
                "\n brandName='" + brandName + '\'' +
                "\n condition='" + condition + '\'' +
                ",\n price=" + price +
                '}';
    }

    @XmlElement(name = "g:id")
    public void setProductId(String productId) {
        this.productId = productId;
    }

    @XmlElement(name = "g:title")
    public void setName(String name) {
        this.name = name;
    }

    @XmlElement(name = "g:description")
    public void setDescription(String description) {
        this.description = description;
    }

    @XmlElement(name = "g:link")
    public void setUrl(String url) {
        this.url = url;
    }

    @XmlElement(name = "g:image_link")
    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @XmlElement(name = "g:brand")
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    @XmlElement(name = "g:condition")
    public void setCondition(String condition) {
        this.condition = condition;
    }

    @XmlElement(name = "g:price")
    public void setPrice(String price) {
        this.price = price;
    }

    @XmlElement(name = "g:availability")
    public void setStockAvailability(String stockAvailability) {
        this.stockAvailability = stockAvailability;
    }

    @XmlElement(name = "g:shipping")
    public void setShipping(Shipping shipping) {
        this.shipping = shipping;
    }

    public String getProductId() {
        return productId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getCondition() {
        return condition;
    }

    public String getUrl() {
        return url;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getBrandName() {
        return brandName;
    }

    public String getPrice() {
        return price;
    }

    public String getStockAvailability() {
        return stockAvailability;
    }

    public Shipping getShipping() {
        return shipping;
    }
}

