package bt.batelco.facades.product.dto;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder = { "country", "service", "price"})
public class Shipping {

    private String country;
    private String service;
    private String price;

    @XmlElement(name = "g:price")
    public void setPrice(String price) {
        this.price = price;
    }

    @XmlElement(name = "g:service")
    public void setService(String service) {
        this.service = service;
    }

    @XmlElement(name = "g:country")
    public void setCountry(String country) {
        this.country = country;
    }

    public String getPrice() {
        return price;
    }

    public String getService() {
        return service;
    }

    public String getCountry() {
        return country;
    }
}
