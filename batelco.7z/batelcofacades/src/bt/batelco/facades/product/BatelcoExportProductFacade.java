package bt.batelco.facades.product;

import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.core.model.media.MediaModel;

public interface BatelcoExportProductFacade {

    /**
     * Generates product feed for Facebook and persists the feed file as Media in Hybris
     * @param mediaModel
     *    Media model
     * @param catalogVersion
     *      Catalog version considered for product fetching
     * @throws Exception
     *          Exception
     */
    public void performProductExport(MediaModel mediaModel, CatalogVersionModel catalogVersion) throws Exception;
}
