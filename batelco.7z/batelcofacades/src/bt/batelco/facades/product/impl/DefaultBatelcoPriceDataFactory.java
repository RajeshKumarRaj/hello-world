package bt.batelco.facades.product.impl;

import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.b2ctelcofacades.price.impl.DefaultTmaPriceDataFactory;
import de.hybris.platform.core.model.c2l.CurrencyModel;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/**
 * Batelco custom price data factory
 */
public class DefaultBatelcoPriceDataFactory extends DefaultTmaPriceDataFactory implements PriceDataFactory {
  public static final String SYMBOL_SUFFIX = " ";

  /**
   * Adjusts {@link DecimalFormat}'s symbol according to given {@link CurrencyModel}.
   * - override to include one extra space between currency and value
   */
  @Override
  protected DecimalFormat adjustSymbol(final DecimalFormat format, final CurrencyModel currencyModel) {
    final String symbol = currencyModel.getSymbol();

    if (symbol != null) {
      final DecimalFormatSymbols symbols = format.getDecimalFormatSymbols(); // does cloning
      final String iso = currencyModel.getIsocode();
      boolean changed = false;

      if (!iso.equalsIgnoreCase(symbols.getInternationalCurrencySymbol())) {
        symbols.setInternationalCurrencySymbol(iso);
        changed = true;
      }

      if (!symbol.equals(symbols.getCurrencySymbol())) {
        symbols.setCurrencySymbol(symbol + SYMBOL_SUFFIX);
        changed = true;
      }

      if (changed) {
        format.setDecimalFormatSymbols(symbols);
      }
    }
    return format;
  }
}
