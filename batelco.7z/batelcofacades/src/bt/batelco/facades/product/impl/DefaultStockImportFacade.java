package bt.batelco.facades.product.impl;

import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.jalo.CatalogManager;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.ordersplitting.WarehouseService;
import de.hybris.platform.ordersplitting.model.WarehouseModel;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.stock.StockService;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import java.util.List;

import bt.batelco.facades.product.StockImportFacade;

/**
 * Default implementation for {@link StockImportFacade}
 */
public class DefaultStockImportFacade implements StockImportFacade {
  private static final Logger LOG = Logger.getLogger(DefaultStockImportFacade.class);

  private static final String DEFAULT_WAREHOUSE_CODE = "default";
  private static final String PRODUCT_CATALOG_CODE = "batelcoProductCatalog";
  private static final String REGEX = ";";
  private static final String LEADING_ZERO_REGEX="^0+(?!$)";
  public static final String TRAILING_DECIMALS_REGEX_ = "\\.[0-9]*$";

  private WarehouseService warehouseService;
  private StockService stockService;
  private ProductService productService;
  private CatalogVersionService catalogVersionService;

  @Override
  public int performImport(List<String> lines) {
    catalogVersionService.setSessionCatalogVersion(PRODUCT_CATALOG_CODE, CatalogManager.ONLINE_VERSION);

    int counter = 0;
    for (String line : lines) {
      try {
        final String[] values = line.split(REGEX);

        if (values.length < 5) {
          LOG.error("Line is not complete: " + line);
          counter++;
          continue;
        }
        StringBuilder productCode = new StringBuilder();
        productCode.append(values[0].replaceFirst(LEADING_ZERO_REGEX, ""));

        if (StringUtils.isNotEmpty(values[2])) {
          String color = values[2].trim().toLowerCase().replace(" ", "_");
          productCode.append("_").append(color);
        }
        ProductModel product = getProduct(productCode.toString());

        int actualAmount = Integer.parseInt(values[3].replaceAll(TRAILING_DECIMALS_REGEX_, ""));
        
        WarehouseModel warehouseModel = getWarehouse(values[4]);

        stockService.updateActualStockLevel(product, warehouseModel, actualAmount, null);
      } catch (final Exception e) {
        LOG.error("Could not import stock for " + line + ": " + e);
        counter++;
      }
    }
    return counter;
  }

  private ProductModel getProduct(String productCode) {
    try {

      return productService.getProductForCode(productCode);
    } catch (RuntimeException ex) {
      LOG.error("Could not find product with code: " + productCode);
      throw ex;
    }
  }

  private WarehouseModel getWarehouse(String warehouseCode) {
    WarehouseModel warehouseModel;
    try {
      warehouseModel = warehouseService.getWarehouseForCode(warehouseCode);
    } catch (RuntimeException ex) {
      LOG.error("Could not find warehouse with code " + warehouseCode + ". Default one will be used.");
      warehouseModel = warehouseService.getWarehouseForCode(DEFAULT_WAREHOUSE_CODE);
    }
    return warehouseModel;
  }

  @Required
  public void setWarehouseService(WarehouseService warehouseService) {
    this.warehouseService = warehouseService;
  }

  @Required
  public void setStockService(StockService stockService) {
    this.stockService = stockService;
  }

  @Required
  public void setProductService(ProductService productService) {
    this.productService = productService;
  }

  @Required
  public void setCatalogVersionService(CatalogVersionService catalogVersionService) {
    this.catalogVersionService = catalogVersionService;
  }
}
