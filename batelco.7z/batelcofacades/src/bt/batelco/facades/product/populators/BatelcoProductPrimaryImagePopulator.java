package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commercefacades.product.converters.populator.ProductPrimaryImagePopulator;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;

public class BatelcoProductPrimaryImagePopulator<SOURCE extends ProductModel, TARGET extends ProductData>
    extends ProductPrimaryImagePopulator<SOURCE, TARGET> {

  @Override
  protected Object getProductAttribute(final ProductModel productModel, final String attribute) {
    final Object value = getModelService().getAttributeValue(productModel, attribute);

    if (value == null && productModel instanceof TmaSimpleProductOfferingModel) {
      TmaPoVariantModel defaultTmaPoVariant = ((TmaSimpleProductOfferingModel) productModel).getDefaultTmaPoVariant();
      if (defaultTmaPoVariant != null) {
        return getModelService().getAttributeValue(defaultTmaPoVariant, attribute);
      }
    }

    if (value == null && productModel instanceof TmaPoVariantModel) {
      final ProductModel baseProduct = ((TmaPoVariantModel) productModel).getTmaBasePo();
      if (baseProduct != null) {
        return getModelService().getAttributeValue(baseProduct, attribute);
      }
    }


    return value;
  }
}
