package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcofacades.converters.populator.TmaProductOfferingBasicPopulator;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;

public class BatelcoProductOfferingBasicPopulator<SOURCE extends ProductModel, TARGET extends ProductData>
    extends TmaProductOfferingBasicPopulator<SOURCE, TARGET> {

  @Override
  public void populate(final SOURCE productModel, final TARGET productData) {
    super.populate(productModel, productData);

    productData.setName((String) getProductAttribute(productModel, ProductModel.NAME));
    productData.setManufacturer((String) getProductAttribute(productModel, ProductModel.MANUFACTURERNAME));
    if (productModel instanceof TmaPoVariantModel) {
      productData.setAverageRating(((TmaPoVariantModel) productModel).getTmaBasePo().getAverageRating());
    } else {
      productData.setAverageRating(productModel.getAverageRating());
    }
  }

  @Override
  protected Object getProductAttribute(final ProductModel productModel, final String attribute) {
    final Object value = getModelService().getAttributeValue(productModel, attribute);
    if (value == null && productModel instanceof TmaPoVariantModel) {
      final ProductModel baseProduct = ((TmaPoVariantModel) productModel).getTmaBasePo();
      if (baseProduct != null) {
        return getProductAttribute(baseProduct, attribute);
      }
    }
    return value;
  }
}
