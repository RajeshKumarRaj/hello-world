package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.classification.features.Feature;
import de.hybris.platform.classification.features.FeatureList;
import de.hybris.platform.commercefacades.product.converters.populator.ProductClassificationPopulator;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import org.apache.commons.collections.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

public class BatelcoProductClassificationPopulator<SOURCE extends ProductModel, TARGET extends ProductData>
    extends ProductClassificationPopulator<SOURCE, TARGET> {

  @Override
  public void populate(final SOURCE productModel, final TARGET productData) throws ConversionException {
    List<Feature> productFeatureList = new ArrayList<>();

    final FeatureList featureList = getClassificationService().getFeatures(productModel);
    if (featureList != null && !featureList.isEmpty()) {
      productFeatureList.addAll(featureList.getFeatures());
    }

    if (productModel instanceof TmaPoVariantModel) {
      final FeatureList variantFeatureList =
          getClassificationService().getFeatures(((TmaPoVariantModel) productModel).getTmaBasePo());
      if (variantFeatureList != null && !variantFeatureList.isEmpty()) {
        productFeatureList.addAll(variantFeatureList.getFeatures());
      }
    }

    if (CollectionUtils.isNotEmpty(productFeatureList)) {
      final FeatureList result = new FeatureList(productFeatureList);
      getProductFeatureListPopulator().populate(result, productData);
    }
  }

}
