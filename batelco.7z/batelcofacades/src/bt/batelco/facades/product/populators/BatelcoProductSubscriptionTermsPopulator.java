package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;

import bt.batelco.core.product.BatelcoSubscriptionTermService;

import de.hybris.platform.commercefacades.product.converters.populator.AbstractProductPopulator;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.TermOfServiceFrequencyData;
import de.hybris.platform.subscriptionservices.enums.TermOfServiceFrequency;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import org.springframework.beans.factory.annotation.Required;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import bt.batelco.facades.product.data.DeviceInstalmentTerm;

public class BatelcoProductSubscriptionTermsPopulator extends
                                                      AbstractProductPopulator<TmaProductOfferingModel, ProductData> {

  private BatelcoSubscriptionTermService subscriptionTermService;
  private Converter<SubscriptionTermModel, DeviceInstalmentTerm> deviceInstallmentConverter;

  @Override
  public void populate(final TmaProductOfferingModel mainPo, final ProductData productData) {
    Set<SubscriptionTermModel> deviceInstallments = getSubscriptionTermService()
        .getSpoApplicableSubscriptionTerms(mainPo, TmaProcessType.ACQUISITION);

    productData.setDeviceInstallments(convertInstallments(deviceInstallments));
  }

  private List<DeviceInstalmentTerm> convertInstallments(Set<SubscriptionTermModel> deviceInstallments) {
    return deviceInstallments.stream().map(source -> deviceInstallmentConverter.convert(source))
        .collect(Collectors.toList());
  }

  protected Converter<SubscriptionTermModel, DeviceInstalmentTerm> getDeviceInstallmentConverter() {
    return deviceInstallmentConverter;
  }

  @Required
  public void setDeviceInstallmentConverter(
      final Converter<SubscriptionTermModel, DeviceInstalmentTerm> deviceInstallmentConverter) {
    this.deviceInstallmentConverter = deviceInstallmentConverter;
  }

  protected BatelcoSubscriptionTermService getSubscriptionTermService() {
    return subscriptionTermService;
  }

  @Required
  public void setSubscriptionTermService(
      final BatelcoSubscriptionTermService subscriptionTermService) {
    this.subscriptionTermService = subscriptionTermService;
  }

}
