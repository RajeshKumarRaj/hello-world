package bt.batelco.facades.cart.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.category.model.CategoryModel;
import de.hybris.platform.commercefacades.order.EntryGroupData;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.order.impl.DefaultCartFacade;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.core.model.media.MediaContainerModel;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.jalo.JaloObjectNoLongerValidException;
import de.hybris.platform.servicelayer.media.MediaService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import bt.batelco.core.cart.BatelcoCartConfigService;
import bt.batelco.core.category.BatelcoCategoryService;
import bt.batelco.facades.cart.BatelcoCartFacade;

/**
 * Default implementation of {@link BatelcoCartFacade}
 */
public class DefaultBatelcoCartFacade extends DefaultCartFacade implements BatelcoCartFacade {

  private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoCartFacade.class);
  private MediaService mediaService;
  private BatelcoCartConfigService cartConfigService;
  private BatelcoCategoryService categoryService;
  
  @Override
  public AbstractOrderEntryModel getCartEntry(int entryNumber) {
	  List<AbstractOrderEntryModel> entries = getCartService().getSessionCart().getEntries();
	  if (entries.size() <= entryNumber) {
	      LOG.warn("Cannot attach acquisition form to entry with number {} because there are only {} entries", entryNumber,
	               entries.size());
	      return null;	
	  }
	  AbstractOrderEntryModel entry = entries.get(entryNumber);
	  return entry;
  }
  
  public InputStream getStreamForMedia(MediaModel mediaModel) {
	  InputStream inputStream = getMediaService().getStreamFromMedia(mediaModel);
	  return inputStream;
  }

  @Override
  public boolean hasEntryWithAcquisitionForm() {
    return getCartService().getSessionCart().getEntries().stream().anyMatch(entry -> getAcquisitionForm(entry) != null);
  }

  @Override
  public MediaModel getAcquisitionForm(AbstractOrderEntryModel entry) {
    MediaContainerModel documents = ((TmaSimpleProductOfferingModel) entry.getProduct()).getDocuments();
    if (documents == null) {
      return null;
    }
    
    String name = getCartConfigService().getAcquisitionFormFormatName();
    
    return getMediaService()
        .getMediaByFormat(documents,
                          getMediaService().getFormat(getCartConfigService().getAcquisitionFormFormatName()));
  }

  public Map<Integer, Long> getEntriesFromGroup(CartData cart, int groupNumber) {
    return getEntryGroupByGroupNumber(cart, groupNumber).map(groupData -> groupData.getOrderEntries().stream()
        .collect(Collectors.toMap(OrderEntryData::getEntryNumber, OrderEntryData::getQuantity)))
        .orElse(Collections.emptyMap());
  }

  private Optional<EntryGroupData> getEntryGroupByGroupNumber(CartData cart, int groupNumber) {
    return cart.getRootGroups().stream().filter(group -> group.getGroupNumber().equals(groupNumber)).findFirst();
  }

  public boolean checkRevertQuantityUpdate(Map<Integer, Long> entries) {
    for (Map.Entry<Integer, Long> groupEntry : entries.entrySet()) {
      try {
        updateCartEntry(groupEntry.getKey(), groupEntry.getValue());
      } catch (final JaloObjectNoLongerValidException | CommerceCartModificationException | IllegalArgumentException ex) {
        LOG.warn("Could not update quantity of product with entry number: {}. {}", groupEntry.getKey(), ex);
        return false;
      }
    }
    return true;
  }

  @Override
  public boolean hasAllRequiredDocuments() {
    CartData cartData = getSessionCart();
    return cartData.getEntries().stream().noneMatch(entry -> entry.getAcquisitionFormUrl() != null
                                                             && entry.getUploadedAcquisitionFormData() == null)
           && cartData.getUploadedCprFront() != null
           && cartData.getUploadedCprBack() != null;
  }

  @Override
  public boolean isAcquisitionFormConfiguredOnEntries() {
    CartData cartData = getSessionCart();
    return cartData.getEntries().stream().noneMatch(this::isAcquisitionFormMissing);
  }

  private boolean isAcquisitionFormMissing(OrderEntryData entry) {
    return entry.getProduct().getCategories().stream()
               .noneMatch(category -> isAddon(getCategoryService().getCategoryForCode(category.getCode())))
           && entry.getAcquisitionFormUrl() == null;
  }

  private boolean isAddon(CategoryModel category) {
    if (category.getCode().equals(getCategoryService().getAddonsCategoryCode())) {
      return true;
    }
    return getCategoryService()
        .getAllSupercategoriesForCategory(getCategoryService().getCategoryForCode(category.getCode()))
        .stream().anyMatch(this::isAddon);
  }

  protected MediaService getMediaService() {
    return mediaService;
  }

  @Required
  public void setMediaService(MediaService mediaService) {
    this.mediaService = mediaService;
  }

  protected BatelcoCartConfigService getCartConfigService() {
    return cartConfigService;
  }

  @Required
  public void setCartConfigService(BatelcoCartConfigService cartConfigService) {
    this.cartConfigService = cartConfigService;
  }

  protected BatelcoCategoryService getCategoryService() {
    return categoryService;
  }

  @Required
  public void setCategoryService(BatelcoCategoryService categoryService) {
    this.categoryService = categoryService;
  }
}
