package bt.batelco.facades.cart.populator;

import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.media.MediaService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.cart.BatelcoCartFacade;
import bt.batelco.facades.order.data.DocumentData;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Populates acquisition form URL on order entry
 */
public class AcquisitionFormOrderEntryPopulator implements Populator<AbstractOrderEntryModel, OrderEntryData> {

  private MediaService mediaService;
  private BatelcoCartFacade cartFacade;

  @Override
  public void populate(final AbstractOrderEntryModel source, final OrderEntryData target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    MediaModel form = getCartFacade().getAcquisitionForm(source);
    if (form == null) {
      return;
    }

    target.setAcquisitionFormUrl(form.getURL());
    MediaModel uploadedForm = source.getAcquisitionForm();
    if (uploadedForm == null) {
      return;
    }
    populateUploadedForm(uploadedForm, target);
  }

  private void populateUploadedForm(MediaModel form, OrderEntryData target) {
    DocumentData uploadedAcquisitionForm=new DocumentData();
    uploadedAcquisitionForm.setFileName(form.getRealFileName());
    uploadedAcquisitionForm.setFileSize(form.getSize());
    target.setUploadedAcquisitionFormData(uploadedAcquisitionForm);
  }

  protected MediaService getMediaService() {
    return mediaService;
  }

  @Required
  public void setMediaService(MediaService mediaService) {
    this.mediaService = mediaService;
  }

  protected BatelcoCartFacade getCartFacade() {
    return cartFacade;
  }

  @Required
  public void setCartFacade(BatelcoCartFacade cartFacade) {
    this.cartFacade = cartFacade;
  }
}
