package bt.batelco.facades.populators;

import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commerceservices.search.resultdata.SearchResultValueData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import org.apache.commons.lang.StringUtils;

public class BatelcoSearchResultProductPopulator implements Populator<SearchResultValueData, ProductData> {

  @Override
  public void populate(SearchResultValueData source, ProductData target) throws ConversionException {
    target.setStorageSize(StringUtils.EMPTY);
  }
}
