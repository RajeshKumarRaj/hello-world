package bt.batelco.facades.populators;

import com.google.common.collect.Sets;

import de.hybris.platform.b2ctelcofacades.data.BpoData;
import de.hybris.platform.b2ctelcofacades.data.BundleTabData;
import de.hybris.platform.b2ctelcofacades.data.FrequencyTabData;
import de.hybris.platform.b2ctelcofacades.price.TmaPriceFacade;
import de.hybris.platform.b2ctelcofacades.product.FrequencyTabDataComparator;
import de.hybris.platform.b2ctelcoservices.enums.TmaProcessType;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContext;
import de.hybris.platform.b2ctelcoservices.pricing.context.TmaPriceContextFactory;
import de.hybris.platform.b2ctelcoservices.services.TmaPoService;
import de.hybris.platform.b2ctelcoservices.services.TmaSubscriptionTermService;
import de.hybris.platform.commercefacades.product.converters.populator.AbstractProductPopulator;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.TermOfServiceFrequencyData;
import de.hybris.platform.subscriptionservices.enums.TermOfServiceFrequency;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import bt.batelco.core.service.BundledProductOfferingGroupsService;
import bt.batelco.facades.product.data.DeviceInstalmentTerm;

public class MergedSpoBundleTabsPopulator extends AbstractProductPopulator<TmaProductOfferingModel, ProductData> {
  private static final TmaProcessType DEFAULT_PROCESS_TYPE = TmaProcessType.ACQUISITION;

  private BundledProductOfferingGroupsService bpoGroupService;

  private TmaPoService tmaPoService;
  private TmaSubscriptionTermService tmaSubscriptionTermService;
  private TmaPriceContextFactory priceContextFactory;
  private TmaPriceFacade tmaPriceFacade;
  private Converter<TmaBundledProductOfferingModel, BpoData> bpoConverter;
  private Converter<ProductModel, ProductData> tmaSubscriptionProductConverter;
  private Converter<TermOfServiceFrequency, TermOfServiceFrequencyData> termOfServiceFrequencyConverter;
  private Converter<SubscriptionTermModel, DeviceInstalmentTerm> deviceInstallmentConverter;

  @Override
  public void populate(final TmaProductOfferingModel mainPo, final ProductData productData) {
    final List<BundleTabData> bundleTabs = new ArrayList<>();

    // Only the top bundle levers will be displayed as tabs, so we get the root bpo.
    Set<TmaBundledProductOfferingModel> rootParents = new HashSet<>();
    mainPo.getParents().forEach(parent -> addRootParent(parent, rootParents));

    rootParents.forEach(rootParent -> bundleTabs.add(getBundleTabData(rootParent, mainPo)));

    productData.setBundleTabs(bundleTabs);
  }

  private BundleTabData getBundleTabData(TmaBundledProductOfferingModel rootParent, TmaProductOfferingModel mainPo) {
    final BundleTabData bundleTab = new BundleTabData();
    bundleTab.setMainPo(getTmaSubscriptionProductConverter().convert(mainPo));
    TmaBundledProductOfferingModel directParentBundle = mainPo.getParents().iterator().next();
    bundleTab.getMainPo().setBoltons(bpoGroupService.getBoltons(directParentBundle)
                                         .stream()
                                         .map(bolton -> getTmaSubscriptionProductConverter().convert(bolton))
                                         .collect(Collectors.toList()));

    bundleTab.setParentBpo(getBpoConverter().convert(rootParent));

    // The BPO has a tree structure, some of the nodes have PO, others just child bpos.
    Set<TmaBundledProductOfferingModel> bundles = new HashSet<>();
    extractApplicableBundles(rootParent, bundles);
    bundleTab.getMainPo().setBundleCode(directParentBundle.getCode());

    Map<String, FrequencyTabData> frequencyTabData = new HashMap<>();
    Set<SubscriptionTermModel> deviceInstallments = getTmaSubscriptionTermService()
        .getApplicableSubscriptionTerms(mainPo, rootParent, TmaProcessType.ACQUISITION);
    // some of the BPOs, as we have started from the root, might not contain our main PO, so we filter them out first.
    bundles
        .stream()
        .filter(bpo -> bpoGroupService.getDevices(bpo).contains(mainPo) || bpoGroupService.getPlans(bpo).contains(mainPo))
        .forEach(bpo -> addFrequencyData(frequencyTabData, bpo, mainPo, deviceInstallments));

    bundleTab.setFrequencyTabs(sortFrequencies(frequencyTabData));
    bundleTab.setDeviceInstallments(convertInstallments(deviceInstallments));

    return bundleTab;
  }

  private List<DeviceInstalmentTerm> convertInstallments(Set<SubscriptionTermModel> deviceInstallments) {
    return deviceInstallments.stream().map(source -> deviceInstallmentConverter.convert(source))
        .collect(Collectors.toList());
  }

  private void addFrequencyData(Map<String, FrequencyTabData> frequencyTabData,
                                TmaBundledProductOfferingModel bpo,
                                TmaProductOfferingModel mainPo, Set<SubscriptionTermModel> deviceInstallments) {
    for (TmaProductOfferingModel plan : bpoGroupService.getPlans(bpo)) {
      Set<SubscriptionTermModel> applicableSubscriptionTerms = getTmaSubscriptionTermService()
          .getApplicableSubscriptionTerms(plan, bpo, TmaProcessType.ACQUISITION);
      if (!applicableSubscriptionTerms.isEmpty()) {
        addFrequencyData(bpo, frequencyTabData, plan, mainPo, applicableSubscriptionTerms, deviceInstallments);
      }
    }
  }

  private void extractApplicableBundles(TmaBundledProductOfferingModel node,
                                        Set<TmaBundledProductOfferingModel> bundles) {
    if (CollectionUtils.isEmpty(node.getChildren())) {
      return;
    }
    if (!CollectionUtils.isEmpty(node.getProductOfferingGroups())) {
      bundles.add(node);
    }
    node.getChildren().forEach(child -> {
      if (child instanceof TmaBundledProductOfferingModel) {
        extractApplicableBundles((TmaBundledProductOfferingModel) child, bundles);
      }
    });
  }

  private void addRootParent(TmaBundledProductOfferingModel bpo, Set<TmaBundledProductOfferingModel> rootParents) {
    if (CollectionUtils.isEmpty(bpo.getParents())) {
      rootParents.add(bpo);
      return;
    }
    bpo.getParents().forEach(parent -> addRootParent(parent, rootParents));
  }

  private void addFrequencyData(final TmaBundledProductOfferingModel bpo,
                                final Map<String, FrequencyTabData> frequencyTabs,
                                final TmaProductOfferingModel planPo,
                                final TmaProductOfferingModel mainPo,
                                final Set<SubscriptionTermModel> subscriptionTerms,
                                final Set<SubscriptionTermModel> deviceInstallments) {

    for (SubscriptionTermModel subscriptionTerm : subscriptionTerms) {
      planPo.setSubscriptionTerm(subscriptionTerm);
      final ProductData subscriptionProductData =
          getTmaSubscriptionProductConverter().convert(planPo);
      subscriptionProductData.setBundleCode(bpo.getCode());

      subscriptionProductData.setDevicePrices(
          deviceInstallments.stream().collect(
              HashMap::new, (map, installment) -> map.put(installment.getId(), getPrice(mainPo, bpo, planPo, installment)), HashMap::putAll));

      subscriptionProductData.setAdditionalSpoPriceInBpo(getPrice(planPo, bpo, planPo, subscriptionTerm));

      subscriptionProductData.setBoltons(
          bpoGroupService.getBoltons(bpo)
              .stream()
              .map(bolton -> getTmaSubscriptionProductConverter().convert(bolton))
              .collect(Collectors.toList()));

      FrequencyTabData frequencyTab = frequencyTabs.computeIfAbsent(
          subscriptionTerm.getName(), key -> generateFrequencyTab(subscriptionTerm));
      frequencyTab.getProducts().add(subscriptionProductData);
      frequencyTabs.put(subscriptionTerm.getName(), frequencyTab);
    }
  }


  private PriceData getPrice(final TmaProductOfferingModel targetProduct,
                             final TmaBundledProductOfferingModel parentBpo,
                             final TmaProductOfferingModel tabProductOffering,
                             final SubscriptionTermModel subscriptionTerm) {
    final TmaPriceContext priceContext = getPriceContextFactory()
        .createBpoPriceContext(parentBpo, Collections.singleton(DEFAULT_PROCESS_TYPE),
                               Collections.singleton(subscriptionTerm), targetProduct,
                               Sets.newHashSet(tabProductOffering));

    return getTmaPriceFacade().getMinimumPrice(priceContext);
  }

  private FrequencyTabData generateFrequencyTab(final SubscriptionTermModel subscriptionTerm) {
    FrequencyTabData frequencyTab = new FrequencyTabData();
    frequencyTab.setTermOfServiceFrequency(getTermOfServiceFrequencyConverter().convert(subscriptionTerm.getTermOfServiceFrequency()));
    frequencyTab.setTermOfServiceNumber(subscriptionTerm.getTermOfServiceNumber() == null ? 0 : subscriptionTerm.getTermOfServiceNumber());
    frequencyTab.setSubscriptionTermName(subscriptionTerm.getName());
    frequencyTab.setCode(subscriptionTerm.getId());
    frequencyTab.setProducts(new ArrayList<>());
    return frequencyTab;
  }

  private List<FrequencyTabData> sortFrequencies(final Map<String, FrequencyTabData> frequencyTabs) {
    final List<FrequencyTabData> sortedFrequencies = new ArrayList<>(frequencyTabs.values());
    sortedFrequencies.sort(new FrequencyTabDataComparator());
    Collections.reverse(sortedFrequencies);
    return sortedFrequencies;
  }

  protected Converter<TmaBundledProductOfferingModel, BpoData> getBpoConverter() {
    return bpoConverter;
  }

  @Required
  public void setBpoConverter(final Converter<TmaBundledProductOfferingModel, BpoData> bpoConverter) {
    this.bpoConverter = bpoConverter;
  }

  protected TmaPoService getTmaPoService() {
    return tmaPoService;
  }

  @Required
  public void setTmaPoService(final TmaPoService tmaPoService) {
    this.tmaPoService = tmaPoService;
  }

  protected TmaSubscriptionTermService getTmaSubscriptionTermService() {
    return tmaSubscriptionTermService;
  }

  @Required
  public void setTmaSubscriptionTermService(
      final TmaSubscriptionTermService tmaSubscriptionTermService) {
    this.tmaSubscriptionTermService = tmaSubscriptionTermService;
  }

  protected TmaPriceContextFactory getPriceContextFactory() {
    return priceContextFactory;
  }

  @Required
  public void setPriceContextFactory(final TmaPriceContextFactory priceContextFactory) {
    this.priceContextFactory = priceContextFactory;
  }

  protected Converter<ProductModel, ProductData> getTmaSubscriptionProductConverter() {
    return tmaSubscriptionProductConverter;
  }

  @Required
  public void setTmaSubscriptionProductConverter(
      final Converter<ProductModel, ProductData> tmaSubscriptionProductConverter) {
    this.tmaSubscriptionProductConverter = tmaSubscriptionProductConverter;
  }

  protected Converter<TermOfServiceFrequency, TermOfServiceFrequencyData> getTermOfServiceFrequencyConverter() {
    return termOfServiceFrequencyConverter;
  }

  @Required
  public void setTermOfServiceFrequencyConverter(
      final Converter<TermOfServiceFrequency, TermOfServiceFrequencyData> termOfServiceFrequencyConverter) {
    this.termOfServiceFrequencyConverter = termOfServiceFrequencyConverter;
  }

  protected Converter<SubscriptionTermModel, DeviceInstalmentTerm> getDeviceInstallmentConverter() {
    return deviceInstallmentConverter;
  }

  @Required
  public void setDeviceInstallmentConverter(
      final Converter<SubscriptionTermModel, DeviceInstalmentTerm> deviceInstallmentConverter) {
    this.deviceInstallmentConverter = deviceInstallmentConverter;
  }

  protected TmaPriceFacade getTmaPriceFacade() {
    return tmaPriceFacade;
  }

  @Required
  public void setTmaPriceFacade(final TmaPriceFacade tmaPriceFacade) {
    this.tmaPriceFacade = tmaPriceFacade;
  }

  @Required
  public void setBpoGroupService(BundledProductOfferingGroupsService bpoGroupService) {
    this.bpoGroupService = bpoGroupService;
  }
}