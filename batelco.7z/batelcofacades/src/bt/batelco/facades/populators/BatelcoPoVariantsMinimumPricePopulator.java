package bt.batelco.facades.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.subscriptionservices.model.OneTimeChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.RecurringChargeEntryModel;
import de.hybris.platform.subscriptionservices.model.SubscriptionPricePlanModel;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;
import java.util.Optional;

/**
 * Batelco price populator for Product Offerings without a base price but with variants
 */
public class BatelcoPoVariantsMinimumPricePopulator implements Populator<ProductModel, ProductData> {

  private PriceDataFactory priceDataFactory;
  private CommonI18NService i18NService;

  @Override
  public void populate(ProductModel source, ProductData target) throws ConversionException {
    if (CollectionUtils.isNotEmpty(source.getEurope1Prices())) {
      return;
    }

    if (source instanceof TmaSimpleProductOfferingModel) {
      final TmaSimpleProductOfferingModel sourceProductOffering = (TmaSimpleProductOfferingModel) source;
      Double minimumPriceValue;
      final Optional<Double> minimumRecurringPriceValueOp = sourceProductOffering.getTmaPoVariants().stream()
          .flatMap(tmaPoVariantModel -> tmaPoVariantModel.getEurope1Prices().stream())
          .filter(priceRowModel -> priceRowModel instanceof SubscriptionPricePlanModel)
          .flatMap(priceRowModel -> ((SubscriptionPricePlanModel) priceRowModel).getRecurringChargeEntries().stream())
          .map(RecurringChargeEntryModel::getPrice)
          .filter(priceValue -> priceValue > 0)
          .min(Double::compareTo);

      if (minimumRecurringPriceValueOp.isPresent()) {
        minimumPriceValue = minimumRecurringPriceValueOp.get();
      } else {
        minimumPriceValue = sourceProductOffering.getTmaPoVariants().stream()
            .flatMap(tmaPoVariantModel -> tmaPoVariantModel.getEurope1Prices().stream())
            .filter(priceRowModel -> priceRowModel instanceof SubscriptionPricePlanModel)
            .flatMap(priceRowModel -> ((SubscriptionPricePlanModel) priceRowModel).getOneTimeChargeEntries().stream())
            .map(OneTimeChargeEntryModel::getPrice)
            .filter(priceValue -> priceValue > 0)
            .min(Double::compareTo).orElse(Double.valueOf(0));
      }

      final PriceData priceData = priceDataFactory.create(PriceDataType.FROM, BigDecimal.valueOf(minimumPriceValue),
                                                          i18NService.getCurrentCurrency().getIsocode());
      target.setPrice(priceData);
    }
  }

  @Required
  public void setPriceDataFactory(PriceDataFactory priceDataFactory) {
    this.priceDataFactory = priceDataFactory;
  }

  @Required
  public void setI18NService(CommonI18NService i18NService) {
    this.i18NService = i18NService;
  }
}
