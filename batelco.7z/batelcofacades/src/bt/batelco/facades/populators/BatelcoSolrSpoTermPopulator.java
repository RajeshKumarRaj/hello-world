package bt.batelco.facades.populators;

import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commerceservices.search.resultdata.SearchResultValueData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;

import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;

public class BatelcoSolrSpoTermPopulator implements Populator<SearchResultValueData, ProductData> {

  private static final String MINIMUM_PRICE_NAME = "minimumPrice";
  private CommonI18NService i18NService;
  private PriceDataFactory priceDataFactory;

  @Override
  public void populate(final SearchResultValueData source, final ProductData target) {
    Double priceValue = (Double) source.getValues().get(MINIMUM_PRICE_NAME);

    if (priceValue != null) {
      CurrencyModel currency = getI18NService().getCurrentCurrency();
      target.setPrice(getPriceDataFactory().create(PriceDataType.FROM,
                                                   BigDecimal.valueOf(priceValue),
                                                   currency.getIsocode()));
    }
  }

  protected CommonI18NService getI18NService() {
    return i18NService;
  }

  @Required
  public void setI18NService(CommonI18NService i18NService) {
    this.i18NService = i18NService;
  }

  protected PriceDataFactory getPriceDataFactory() {
    return priceDataFactory;
  }

  @Required
  public void setPriceDataFactory(PriceDataFactory priceDataFactory) {
    this.priceDataFactory = priceDataFactory;
  }
}
