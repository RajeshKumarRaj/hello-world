package bt.batelco.facades.price.converters;

import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.TermOfServiceFrequencyData;
import de.hybris.platform.subscriptionservices.enums.TermOfServiceFrequency;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;
import de.hybris.platform.converters.Populator;

import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.product.data.DeviceInstalmentTerm;

public class BatelcoDeviceInstallmentPopulator<S extends SubscriptionTermModel, T extends DeviceInstalmentTerm>
    implements Populator<S, T> {

  private Converter<TermOfServiceFrequency, TermOfServiceFrequencyData> termOfServiceFrequencyConverter;

  @Override
  public void populate(final S source, final T target) throws ConversionException {
    target.setCode(source.getId());
    target.setContractTermNumber(source.getTermOfServiceNumber());
    target.setName(source.getName());
    target.setFrequency(termOfServiceFrequencyConverter.convert(source.getTermOfServiceFrequency()));
  }

  protected Converter<TermOfServiceFrequency, TermOfServiceFrequencyData> getTermOfServiceFrequencyConverter() {
    return termOfServiceFrequencyConverter;
  }

  @Required
  public void setTermOfServiceFrequencyConverter(
      final Converter<TermOfServiceFrequency, TermOfServiceFrequencyData> termOfServiceFrequencyConverter) {
    this.termOfServiceFrequencyConverter = termOfServiceFrequencyConverter;
  }
}
