package bt.batelco.facades.order;

import de.hybris.platform.acceleratorfacades.order.AcceleratorCheckoutFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;

import java.io.IOException;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import bt.batelco.facades.payment.data.PaymentModeData;
import bt.batelco.facades.payment.dto.InitRequest;
import bt.batelco.paymentcallback.queues.data.BTPaymentCallbackRequestDTO;

/**
 * Facade that extends AcceleratorCheckoutFacade with batelco related functionality.
 */
public interface BatelcoCheckoutFacade extends AcceleratorCheckoutFacade {
  /**
   * Creates an invoice payment details on the cart
   *
   * @param billingAddress  the billing address that will be store on the payment details
   * @param paymentTypeCode code of the selected payment type
   * @return true if operation succeeded
   */
  boolean setInvoicePaymentDetails(AddressData billingAddress, String paymentTypeCode);

  /**
   * Get cart data with all the product set on cart entry
   *
   * @return CartData
   */
  CartData getCartData();

  /**
   * Gets base payment types
   *
   * @return the list of {@link PaymentModeData}
   */
  List<PaymentModeData> getCheckoutPaymentTypes();
  
  List<StandardPaymentModeModel> getOnlinePaymentModes();
  
  InitRequest createInitPaymentRequest();
  
  String getPaymentRedirectUrl(ResponseEntity<String> responseEntity)  throws JsonMappingException,IOException, JsonParseException;
  
  //boolean addPayInfoToCart();
  
  CartModel getSessionCart();
  
  OrderData paymentCallbackCreateOrder(CartModel cart) throws InvalidCartException;
  
  CartModel getUserCartByAccountNumber(String accountNumber, BTPaymentCallbackRequestDTO btPaymentCallbackRequestDTO);
  
}
