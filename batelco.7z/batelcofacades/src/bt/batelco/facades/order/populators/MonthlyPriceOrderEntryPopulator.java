package bt.batelco.facades.order.populators;

import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.order.CalculationService;
import de.hybris.platform.order.exceptions.CalculationException;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.BillingTimeData;
import de.hybris.platform.subscriptionfacades.data.OrderEntryPriceData;
import de.hybris.platform.subscriptionservices.model.BillingTimeModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;

import javax.annotation.Nonnull;

public class MonthlyPriceOrderEntryPopulator implements Populator<AbstractOrderEntryModel, OrderEntryData> {

  private static final String MONTHLY = "monthly";

  private PriceDataFactory priceDataFactory;
  private Converter<BillingTimeModel, BillingTimeData> billingTimeConverter;

  @Override
  public void populate(AbstractOrderEntryModel source, OrderEntryData target)
      throws ConversionException {

    final Collection<AbstractOrderEntryModel> abstractOrdersEntries = new ArrayList<>();
    abstractOrdersEntries.add(source);
    if (source.getChildEntries() != null) {
      abstractOrdersEntries.addAll(source.getChildEntries());
    }

    abstractOrdersEntries.stream()
        .filter(entry -> entry.getOrder() != null && entry.getOrder().getBillingTime() != null &&
                         MONTHLY.equalsIgnoreCase(entry.getOrder().getBillingTime().getCode()))
        .findFirst()
        .ifPresent(entry -> {
          OrderEntryPriceData orderEntryPriceDataForEntry = createOrderEntryPriceDataForEntry(entry);
          target.setMonthlyPrice(orderEntryPriceDataForEntry);
        });
  }

  private OrderEntryPriceData createOrderEntryPriceDataForEntry(@Nonnull final AbstractOrderEntryModel entry) {
    final OrderEntryPriceData orderEntryPrice = new OrderEntryPriceData();
    orderEntryPrice.setTotalPrice(createPrice(entry, entry.getTotalPrice()));
    orderEntryPrice.setBasePrice(createPrice(entry, entry.getBasePrice()));
    final BillingTimeData billingTime = billingTimeConverter.convert(entry.getOrder().getBillingTime());
    orderEntryPrice.setBillingTime(billingTime);

    return orderEntryPrice;
  }

  private PriceData createPrice(final AbstractOrderEntryModel orderEntry, final Double val) {
    return priceDataFactory.create(PriceDataType.BUY, BigDecimal.valueOf(val),
                                   orderEntry.getOrder().getCurrency());
  }

  @Required
  public void setPriceDataFactory(PriceDataFactory priceDataFactory) {
    this.priceDataFactory = priceDataFactory;
  }

  @Required
  public void setBillingTimeConverter(Converter<BillingTimeModel, BillingTimeData> billingTimeConverter) {
    this.billingTimeConverter = billingTimeConverter;
  }
}
