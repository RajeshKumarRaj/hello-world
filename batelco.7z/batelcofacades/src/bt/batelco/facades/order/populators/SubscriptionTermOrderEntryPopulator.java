package bt.batelco.facades.order.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaCartSubscriptionInfoModel;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.SubscriptionTermData;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import org.springframework.beans.factory.annotation.Required;

public class SubscriptionTermOrderEntryPopulator implements Populator<AbstractOrderEntryModel, OrderEntryData> {

    private Converter<SubscriptionTermModel, SubscriptionTermData> subscriptionTermConverter;

    @Override
    public void populate(AbstractOrderEntryModel abstractOrderEntryModel, OrderEntryData orderEntryData) throws ConversionException {
        TmaCartSubscriptionInfoModel subscriptionInfoModel= abstractOrderEntryModel.getSubscriptionInfo();
        if(subscriptionInfoModel == null){
            return;
        }

        SubscriptionTermModel subscriptionTermModel= subscriptionInfoModel.getSubscriptionTerm();

        if(subscriptionTermModel == null){
            return;
        }

        orderEntryData.setSubscriptionTerm(getSubscriptionTermConverter().convert(subscriptionTermModel));
    }


    public Converter<SubscriptionTermModel, SubscriptionTermData> getSubscriptionTermConverter() {
        return subscriptionTermConverter;
    }

    @Required
    public void setSubscriptionTermConverter(Converter<SubscriptionTermModel, SubscriptionTermData> subscriptionTermConverter) {
        this.subscriptionTermConverter = subscriptionTermConverter;
    }
}
