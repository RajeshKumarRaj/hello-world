package bt.batelco.facades.order.populators;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.product.PriceDataFactory;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.subscriptionfacades.data.BillingTimeData;
import de.hybris.platform.subscriptionfacades.data.OrderPriceData;
import de.hybris.platform.subscriptionservices.model.BillingTimeModel;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Required;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;

/**
 * Custom class used to populate {@link OrderData} order data based on values of {@link OrderModel} order model.
 */
public class BatelcoOrderPopulator implements Populator<OrderModel, OrderData> {
  private static final String SEPARATOR_REGEX = ",";
  private static final List<String> DEFAULT_MONTHLY_BILLING_CODES = Arrays.asList("monthly");
  private static final List<String> DEFAULT_TOTAL_PAY_BILLING_CODES = Arrays.asList("paynow", "vat");
  private static final String MONTHLY_BILLING_CODES_CONFIG = "order.details.total.monthly.billing.codes";
  private static final String TOTAL_PAY_BILLING_CODES_CONFIG = "order.details.total.pay.billing.codes";
  private static final String DECIMAL_FORMAT = "#.000";
  private static final int SCALE = 2;

  private PriceDataFactory priceDataFactory;
  private ConfigProviderService configProviderService;
  private Converter<BillingTimeModel, BillingTimeData> billingTimeConverter;
  private Converter<UserModel, CustomerData> customerConverter;

  @Override
  public void populate(final OrderModel source, final OrderData target) throws ConversionException {
    target.setPreorder(source.getPreorder());
    target.setCprId(source.getCprId());
    populateBillingTime(source, target);
    populatePrices(source, target);
    target.setUser(customerConverter.convert(source.getUser()));
  }

  private void populatePrices(OrderModel source, OrderData target) {
    if (CollectionUtils.isNotEmpty(target.getOrderPrices())) {
      final List<String> monthlyBillingCodes =
          getConfigBillingTimes(MONTHLY_BILLING_CODES_CONFIG, DEFAULT_MONTHLY_BILLING_CODES);
      final List<String> payBillingCodes =
          getConfigBillingTimes(TOTAL_PAY_BILLING_CODES_CONFIG, DEFAULT_TOTAL_PAY_BILLING_CODES);

      BigDecimal monthlyTotalPay = BigDecimal.ZERO;
      BigDecimal onlineTotalPay = BigDecimal.ZERO;

      for (OrderPriceData orderPriceData : target.getOrderPrices()) {
        if (monthlyBillingCodes.contains(orderPriceData.getBillingTime().getCode().toLowerCase())) {
          monthlyTotalPay = monthlyTotalPay.add(orderPriceData.getTotalPrice().getValue());
        } else if (payBillingCodes.contains(orderPriceData.getBillingTime().getCode().toLowerCase())) {
          onlineTotalPay = onlineTotalPay.add(orderPriceData.getTotalPrice().getValue());
        }
      }

      target.setOnlineTotalPay(createPrice(source, getFormattedPrice(onlineTotalPay)));
      target.setMonthlyTotalPay(createPrice(source, monthlyTotalPay));
    }
  }

  private BigDecimal getFormattedPrice(final BigDecimal onlineTotalPay) {
    return new BigDecimal(new DecimalFormat(DECIMAL_FORMAT).format(onlineTotalPay.setScale(SCALE, RoundingMode.DOWN)));
  }

  private void populateBillingTime(final OrderModel source, final OrderData target) {
    final BillingTimeModel billingTime = source.getBillingTime();
    if (billingTime != null) {
      target.setBillingTime(billingTimeConverter.convert(source.getBillingTime()));
    }
  }

  private List<String> getConfigBillingTimes(String key, List<String> defaultCodes) {
    List<String> configuredCodes = configProviderService.<List<String>>get(key)
        .conversion(config -> Arrays.asList(config.split(SEPARATOR_REGEX))).convert();

    return CollectionUtils.isNotEmpty(configuredCodes) ? configuredCodes : defaultCodes;
  }

  private PriceData createPrice(final OrderModel orderModel, final BigDecimal val) {
    return priceDataFactory.create(PriceDataType.BUY, val, orderModel.getCurrency());
  }

  @Required
  public void setBillingTimeConverter(Converter<BillingTimeModel, BillingTimeData> billingTimeConverter) {
    this.billingTimeConverter = billingTimeConverter;
  }

  @Required
  public void setPriceDataFactory(PriceDataFactory priceDataFactory) {
    this.priceDataFactory = priceDataFactory;
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }

  @Required
  public void setCustomerConverter(Converter<UserModel, CustomerData> customerConverter) {
    this.customerConverter = customerConverter;
  }
}
