package bt.batelco.facades.order.impl;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.acceleratorfacades.order.impl.DefaultAcceleratorCheckoutFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.commercefacades.order.data.OrderData;
import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.commercefacades.product.ProductFacade;
import de.hybris.platform.commercefacades.product.ProductOption;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.commercefacades.user.data.AddressData;
import de.hybris.platform.commerceservices.service.data.CommerceCheckoutParameter;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.order.payment.PaymentInfoModel;
import de.hybris.platform.core.model.order.payment.PaymentModeModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.order.InvalidCartException;
import de.hybris.platform.payment.dto.BillingInfo;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.util.Config;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import bt.batelco.core.customer.service.BatelcoCustomerAccountService;
import bt.batelco.core.eligibility.service.BatelcoPaymentEligibilityService;
import bt.batelco.core.model.BatelcoPaymentInfoModel;
import bt.batelco.core.order.service.BatelcoPaymentModeService;
import bt.batelco.facades.order.BatelcoCheckoutFacade;
import bt.batelco.facades.payment.data.PaymentModeData;
import bt.batelco.facades.payment.dto.InitPayment;
import bt.batelco.facades.payment.dto.InitPaymentCartItem;
import bt.batelco.facades.payment.dto.InitPaymentData;
import bt.batelco.facades.payment.dto.InitPaymentResponse;
import bt.batelco.facades.payment.dto.InitRequest;
import bt.batelco.facades.payment.dto.InitResponse;
import bt.batelco.facades.payment.dto.PaymentCart;
import bt.batelco.paymentcallback.queues.data.BTPaymentCallbackRequestDTO;

import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;

public class DefaultBatelcoCheckoutFacade extends DefaultAcceleratorCheckoutFacade implements BatelcoCheckoutFacade {

  private static final List<ProductOption> PRODUCT_OPTIONS = Arrays.asList(ProductOption.BASIC,
                                                                           ProductOption.PRICE,
                                                                           ProductOption.CATEGORIES);
  private static final String RESTRICT_PAYMENT_TYPE_SELECTION_CONFIG = "online.payment.checkout.selection.restrict.to";

  private ProductFacade productFacade;
  private BatelcoPaymentModeService batelcoPaymentModeService;
  private BatelcoPaymentEligibilityService paymentEligibilityService;
private BatelcoCustomerAccountService batelcoCustomerAccountService;
  
  
public void setBatelcoCustomerAccountService(BatelcoCustomerAccountService batelcoCustomerAccountService) {
	this.batelcoCustomerAccountService = batelcoCustomerAccountService;
}

private Converter<PaymentModeModel, PaymentModeData> paymentModeConverter;
  private ConfigProviderService configService;
  

  @Override
  public boolean setInvoicePaymentDetails(AddressData billingAddress, String paymentTypeCode) {
    final PaymentInfoModel invoicePaymentInfoModel = getBatelcoCustomerAccountService()
        .createPaymentInfoForCustomer(getCurrentUserForCheckout(), createBillingInfo(billingAddress));
    setPaymentModeOnCurrentcart(paymentTypeCode);
    return setPaymentDetailsOnCurrentCart(invoicePaymentInfoModel);
  }

  @Override
  public CartData getCartData() {
    final CartData cartData = getCheckoutCart();
    cartData.setEntries(removeEmptyEntries(cartData.getEntries()));
    if (cartData.getEntries() == null || cartData.getEntries().isEmpty()) {
      return cartData;
    }

    cartData.getEntries().stream().filter(entry -> entry.getProduct() != null).forEach(entry -> {
      final String productCode = entry.getProduct().getCode();
      final ProductData product = productFacade.getProductForCodeAndOptions(productCode, PRODUCT_OPTIONS);
      entry.setProduct(product);
    });

    return cartData;
  }
  
  @Override
  public List<StandardPaymentModeModel> getOnlinePaymentModes(){
	  return batelcoPaymentModeService.getApplicableCheckoutPaymentTypes(true);
  }

  @Override
  public List<PaymentModeData> getCheckoutPaymentTypes() {
    final CartData cartData = getCheckoutCart();
    // TODO BAT-1746 add payment methods for preorder too and unify behaviour?!
    if (cartData.isPreorderFee()) {
      return paymentModeConverter.convertAll(batelcoPaymentModeService.getApplicableCheckoutPaymentTypes(true));
    }

    String restrictedOption = configService.<String>get(RESTRICT_PAYMENT_TYPE_SELECTION_CONFIG)
        .conversion(String::valueOf).onMissing(useDefault(Strings.EMPTY))
        .convert();
    if (StringUtils.isNotEmpty(restrictedOption)) {
      return Collections.singletonList(paymentModeConverter.convert(batelcoPaymentModeService.getPaymentModeForCode(restrictedOption)));
    }

    boolean isEligibleForCheckoutOnlinePayment =
        paymentEligibilityService.isEligibleForCheckoutOnlinePayment(getCurrentUserForCheckout());
    return paymentModeConverter.convertAll(batelcoPaymentModeService.getApplicableCheckoutPaymentTypes(isEligibleForCheckoutOnlinePayment));
    //boolean offlineOnly = !isEligibleForCheckoutOnlinePayment;
    //return paymentModeConverter.convertAll(batelcoPaymentModeService.getApplicableCheckoutPaymentTypes(offlineOnly));
  }

  private List<OrderEntryData> removeEmptyEntries(final List<OrderEntryData> allEntries) {
    if (CollectionUtils.isEmpty(allEntries)) {
      return Collections.emptyList();
    }

    final List<OrderEntryData> realEntries = new ArrayList<>();
    for (final OrderEntryData entry : allEntries) {
      if (entry.getProduct() != null) {
        realEntries.add(entry);
      }
    }

    if (CollectionUtils.isEmpty(realEntries)) {
      return Collections.emptyList();
    } else {
      return realEntries;
    }
  }

  private void setPaymentModeOnCurrentcart(String paymentTypeCode) {
    final PaymentModeModel paymentModeModel = batelcoPaymentModeService.getPaymentModeForCode(paymentTypeCode);

    CartModel cartModel = getCart();
    cartModel.setPaymentMode(paymentModeModel);
    getModelService().save(cartModel);
    getModelService().refresh(cartModel);
  }

  private boolean setPaymentDetailsOnCurrentCart(PaymentInfoModel invoicePaymentInfoModel) {
    CartModel cartModel = getCart();
    CommerceCheckoutParameter parameter = createCommerceCheckoutParameter(cartModel, true);
    parameter.setPaymentInfo(invoicePaymentInfoModel);
    return getCommerceCheckoutService().setPaymentInfo(parameter);
  }


  private BillingInfo createBillingInfo(AddressData billingAddressData) {
    final BillingInfo billingInfo = new BillingInfo();
    billingInfo.setCity(billingAddressData.getTown());
    billingInfo
        .setCountry(billingAddressData.getCountry() == null ? null : billingAddressData.getCountry().getIsocode());
    billingInfo.setRegion(billingAddressData.getRegion() == null ? null : billingAddressData.getRegion().getIsocode());
    billingInfo.setFirstName(billingAddressData.getFirstName());
    billingInfo.setLastName(billingAddressData.getLastName());
    billingInfo.setEmail(billingAddressData.getEmail());
    billingInfo.setPhoneNumber(billingAddressData.getPhone());
    billingInfo.setPostalCode(billingAddressData.getPostalCode());
    billingInfo.setStreet1(billingAddressData.getLine1());
    billingInfo.setStreet2(billingAddressData.getLine2());
    return billingInfo;
  }

  public BatelcoCustomerAccountService getBatelcoCustomerAccountService() {
    return (BatelcoCustomerAccountService) getCustomerAccountService();
  }

  @Required
  public void setProductFacade(ProductFacade productFacade) {
    this.productFacade = productFacade;
  }

  @Required
  public void setBatelcoPaymentModeService(BatelcoPaymentModeService batelcoPaymentModeService) {
    this.batelcoPaymentModeService = batelcoPaymentModeService;
  }

  @Required
  public void setPaymentEligibilityService(BatelcoPaymentEligibilityService paymentEligibilityService) {
    this.paymentEligibilityService = paymentEligibilityService;
  }

  @Required
  public void setPaymentModeConverter(Converter<PaymentModeModel, PaymentModeData> paymentModeConverter) {
    this.paymentModeConverter = paymentModeConverter;
  }

  public ConfigProviderService getConfigService() {
    return configService;
  }

  @Required
  public void setConfigService(ConfigProviderService configService) {
    this.configService = configService;
  }


@Override
public InitRequest createInitPaymentRequest() {
	
	System.out.println("cart --- code"+getCart().getCode() + "cart -- -GUID" + getCart().getGuid());
	

	InitRequest initRequest = new InitRequest();
    
    InitPayment initPayment = new InitPayment();
    
    InitPaymentData initPaymentData = new InitPaymentData();
    
    PaymentCart paymentCart = new PaymentCart();
    
    InitPaymentCartItem[] initPaymentCartItem = new InitPaymentCartItem[1];
    
    CartModel cartModel = getCart();
    String paymentmode = cartModel.getPaymentMode().getCode();
    
    if(paymentmode.equalsIgnoreCase("batelco_online_credit_payment")) {
    	initPaymentData.setCardType("CREDIT");
    	initPaymentData.setRedirectErrorURL(Config.getParameter("payment.credit.RedirectErrorURL"));
    	initPaymentData.setRedirectURL(Config.getParameter("payment.credit.RedirectURL"));
    } else if (paymentmode.equalsIgnoreCase("batelco_online_debit_payment")) {
    	initPaymentData.setCardType("DEBIT");
    	initPaymentData.setRedirectErrorURL(Config.getParameter("payment.debit.RedirectErrorURL"));
    	initPaymentData.setRedirectURL(Config.getParameter("payment.debit.RedirectURL"));
    }
    
    
    
    initPaymentData.setChannel(Config.getParameter("payment.channel"));
    initPaymentData.setCustomerId(Config.getParameter("payment.CustomerID"));
    initPaymentData.setCustomerIdType(Config.getParameter("payment.CustomerIDType"));
    initPaymentData.setCustomerName("Lokesh");
    initPaymentData.setIsLoggedIn("true");
    initPaymentData.setPassword(Config.getParameter("payment.password"));
    initPaymentData.setUsername(Config.getParameter("payment.username"));
    initPaymentData.setPaymentConfig(Config.getParameter("payment.PaymentConfig"));
    initPaymentData.setPaymentId("");
    initPaymentData.setPaymentMode(Config.getParameter("payment.PaymentMode"));
    initPaymentData.setPaymentSource(Config.getParameter("payment.PaymentSource"));
    initPaymentData.setPaymentType(Config.getParameter("payment.PaymentType"));
    initPaymentData.setPaymentTotalAmount(32.3);
    
    
    
    initPaymentCartItem[0]= new InitPaymentCartItem();
    
    initPaymentCartItem[0].setAccountNumber(Config.getParameter("payment.accountNumber"));
    initPaymentCartItem[0].setAccountStatus(Config.getParameter("payment.accountStatus"));
    initPaymentCartItem[0].setAccountSubNo(Config.getParameter("payment.accountSubNo"));
    initPaymentCartItem[0].setAmount(32.3);
    initPaymentCartItem[0].setSubType(Config.getParameter("payment.SubType"));
    initPaymentCartItem[0].setTelNo(Config.getParameter("payment.telno"));
    initPaymentCartItem[0].setTelStatus(Config.getParameter("payment.telstatus"));
    initPaymentCartItem[0].setType(Config.getParameter("payment.type"));
    
    initPaymentData.setTransUniqueID(Config.getParameter("payment.TransUniqueID"));
    initPaymentData.setCustomerIP("::1");
    
    
    
    paymentCart.setInitPaymentCartItem(initPaymentCartItem);
    initPaymentData.setPaymentCart(paymentCart);
    //initP.setInitPayment(initPaymentData);
    initPayment.setInitPaymentData(initPaymentData);
    initRequest.setInitPayment(initPayment);
	
	return initRequest;
}

@Override
public String getPaymentRedirectUrl(ResponseEntity<String> responseEntity) throws JsonMappingException, IOException, JsonParseException {
	
	try {
		
	ObjectMapper mapper = new ObjectMapper();
	
	InitResponse initResponse = mapper.readValue(responseEntity.getBody(), InitResponse.class);
	
	System.out.println(initResponse.getInitPaymentResponseObject().getInitPaymentResultObject().getPaymentRedirectURL());
	
	return initResponse.getInitPaymentResponseObject().getInitPaymentResultObject().getPaymentRedirectURL();
	
	}catch(JsonProcessingException e) {
		e.printStackTrace();
		return null; 
		
	}catch(Exception e) {
		e.printStackTrace();
		return null;
	}
	
}

/*@Override
public boolean addPayInfoToCart() {
	
	final CartModel cartmodel = getCartService().getSessionCart();
	final PaymentInfoModel paymentInfo = cartmodel.getPaymentInfo();
	
	System.out.println(paymentInfo);
	
	//paymentInfo.set
	
	return Boolean.TRUE;
			
}*/

@Override
public OrderData paymentCallbackCreateOrder(CartModel cart) throws InvalidCartException {
	
	//final CartModel cartModel = getCart();
	
	if (cart != null)
	{
			beforePlaceOrder(cart);
			final OrderModel orderModel = placeOrder(cart);
			
			if (orderModel != null)
			{
				getCartService().removeSessionCart();
				getModelService().remove(cart);
				getModelService().refresh(orderModel);
			}
			if (orderModel != null)
			{
				return getOrderConverter().convert(orderModel);
			}
	}
	
	return null;
}



@Override
public CartModel getSessionCart() {
	return getCartService().getSessionCart();
	
}

@Override
public CartModel getUserCartByAccountNumber(String accountNumber, BTPaymentCallbackRequestDTO btPaymentCallbackRequestDTO) {
	
	String cartCode = Config.getParameter("cart.Code");
	
	String account_Number = Config.getParameter("user.accountNumber");
	
	//UserModel user = getUserService().getUserForUID(uid);
	
	CustomerModel customer = getBatelcoCustomerAccountService().findCustomerModelByAccountNumber(account_Number);
	
	BatelcoPaymentInfoModel paymentInfo = new BatelcoPaymentInfoModel();
	
	paymentInfo.setAuthcode(btPaymentCallbackRequestDTO.getAuthCode());
	paymentInfo.setPaymentRefNo(btPaymentCallbackRequestDTO.getPaymentRefNo());
	paymentInfo.setStatus(btPaymentCallbackRequestDTO.getStatus());
	paymentInfo.setTransactionNo(btPaymentCallbackRequestDTO.getTransactionNo());
	
	/*DateFormat formatter = new SimpleDateFormat("dd/MMM-yyyy,HH:mm:ss aaa");
	Date date = formatter.parse(testDate);*/
	
	//paymentInfo.setTransactionDateTime(btPaymentCallbackRequestDTO.getDateTime());
	
	//paymentInfo.setOutstandingAmount(value);
	
	getModelService().save(paymentInfo);
	
	Collection<CartModel> carts = customer.getCarts();
	
	for (CartModel cart : carts) {
		
		if(CollectionUtils.isNotEmpty(cart.getChildren())) {
			cart.setBatelcoPaymentInfo(paymentInfo);
			getModelService().save(cart);
			return cart;
		}
		
	}
	
	return null;
}




}

