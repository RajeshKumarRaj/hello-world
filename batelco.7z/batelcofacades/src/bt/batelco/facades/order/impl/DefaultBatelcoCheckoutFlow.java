package bt.batelco.facades.order.impl;

import de.hybris.platform.acceleratorfacades.flow.impl.DefaultCheckoutFlowFacade;
import de.hybris.platform.commercefacades.order.data.CartData;

public class DefaultBatelcoCheckoutFlow extends DefaultCheckoutFlowFacade {

  @Override
  public boolean hasNoPaymentInfo() {
    final CartData cartData = getCheckoutCart();
    return cartData == null || cartData.getBatelcoPaymentInfo() == null;
  }

}
