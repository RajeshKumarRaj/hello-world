package bt.batelco.facades.order.impl;

import de.hybris.platform.b2ctelcofacades.data.TmaSubscriptionBaseData;
import de.hybris.platform.b2ctelcofacades.order.impl.DefaultTmaCartFacade;
import de.hybris.platform.b2ctelcoservices.model.TmaBundledProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaCartSubscriptionInfoModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commercefacades.order.data.CartModificationData;
import de.hybris.platform.commerceservices.order.CommerceCartModificationException;
import de.hybris.platform.commerceservices.service.data.CommerceCartParameter;
import de.hybris.platform.subscriptionservices.model.SubscriptionTermModel;

import org.apache.commons.lang.StringUtils;
import org.mockito.internal.util.collections.Sets;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class BatelcoTmaCartFacade extends DefaultTmaCartFacade {

  @Override
  public CartModificationData addProductOfferingToCart(final String spoCode, final long quantity, final String processType,
                                                       final String rootBpoCode,
                                                       final int cartGroupNo, final String subscriptionTermId, final String subscriberId, final String subscriberBillingId)
      throws CommerceCartModificationException
  {
    final TmaProductOfferingModel simpleProductOffering = getTmaPoService().getPoForCode(spoCode);

    if (StringUtils.isEmpty(processType))
    {
      throw new CommerceCartModificationException("Process type cannot be empty");
    }
    if (!(simpleProductOffering instanceof TmaSimpleProductOfferingModel))
    {
      throw new CommerceCartModificationException("Wrong type for product offering with code:" + spoCode + ".It should be "
                                                  + TmaSimpleProductOfferingModel._TYPECODE);
    }
    if (StringUtils.isNotEmpty(rootBpoCode))
    {
      final TmaProductOfferingModel rootProductOffering = getTmaPoService().getPoForCode(rootBpoCode);
      if (!(rootProductOffering instanceof TmaBundledProductOfferingModel))
      {
        throw new CommerceCartModificationException(
            "Wrong type for product offering with code:" + rootBpoCode + ".It should be "
            + TmaBundledProductOfferingModel._TYPECODE);
      }
    }
    final TmaCartSubscriptionInfoModel subscriptionInfoModel = createTmaCartSubscriptionInfoModel(subscriptionTermId,
                                                                                                  subscriberId, subscriberBillingId, processType);

    final CommerceCartParameter parameter = new CommerceCartParameter();
    parameter.setEnableHooks(true);
    parameter.setCart(getCartService().getSessionCart());
    parameter.setProduct(simpleProductOffering);
    parameter.setQuantity(quantity);
    parameter.setBpoCode(rootBpoCode);
    parameter.setProcessType(processType);
    parameter.setSubscriptionInfo(subscriptionInfoModel);
    if (cartGroupNo == -1)
    {
      parameter.setEntryGroupNumbers(Collections.emptySet());
    }
    else
    {
      parameter.setEntryGroupNumbers(Sets.newSet(cartGroupNo));
    }
    return getCartModificationConverter().convert(getCommerceCartService().addToCart(parameter));
  }

  private TmaCartSubscriptionInfoModel createTmaCartSubscriptionInfoModel(final String subscriptionTermId,
                                                                          final String subscriberId, final String subscriberBillingId, final String processType)
  {
    TmaCartSubscriptionInfoModel subscriptionInfoModel = null;
    if (StringUtils.isNotEmpty(subscriptionTermId))
    {
      subscriptionInfoModel = new TmaCartSubscriptionInfoModel();
      final SubscriptionTermModel subscriptionTerm = getSubscriptionTermService().getSubscriptionTerm(subscriptionTermId);
      if (subscriptionTerm != null)
      {
        subscriptionInfoModel.setSubscriptionTerm(subscriptionTerm);
      }
    }

    if (subscriptionInfoModel == null)
    {
      subscriptionInfoModel = new TmaCartSubscriptionInfoModel();
    }
    subscriptionInfoModel.setSubscriberIdentity(subscriberId);

    return subscriptionInfoModel;
  }
}
