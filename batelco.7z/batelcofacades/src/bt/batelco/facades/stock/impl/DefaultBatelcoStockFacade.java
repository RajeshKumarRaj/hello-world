package bt.batelco.facades.stock.impl;

import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.basecommerce.enums.StockLevelStatus;
import de.hybris.platform.commercefacades.product.data.StockData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.stock.BatelcoStockFacade;

/**
 * Default implementation for {@link BatelcoStockFacade}
 */
public class DefaultBatelcoStockFacade implements BatelcoStockFacade {

  private static final Logger LOG = Logger.getLogger(DefaultBatelcoStockFacade.class);

  private ProductService productService;
  private Converter<StockLevelStatus, StockData> stockLevelStatusConverter;
  private Converter<ProductModel, StockData> stockConverter;

  @Override
  public StockData evaluateStockLevel(String prodCode, StockLevelStatus defaultLevelStatus) {
    try {
      final ProductModel productModel = productService.getProductForCode(prodCode);
      if (productModel == null) {
        LOG.debug("No product found");
        return null;
      }
      if (productModel instanceof TmaSimpleProductOfferingModel) {
        TmaSimpleProductOfferingModel product = (TmaSimpleProductOfferingModel) productModel;

        if (CollectionUtils.isNotEmpty(product.getTmaPoVariants())) {
          LOG.debug("Stock evaluated for all variants");
          return stockLevelStatusConverter.convert(findStockLevelFromVariants(product));
        }
      }
      return stockLevelStatusConverter.convert(defaultLevelStatus);
    } catch (final UnknownIdentifierException ex) {
      LOG.debug("Product is no longer visible to the customergroup");
      return stockLevelStatusConverter.convert(StockLevelStatus.OUTOFSTOCK);
    }
  }

  private StockLevelStatus findStockLevelFromVariants(TmaSimpleProductOfferingModel productModel) {
    if (productModel.getTmaPoVariants().stream()
        .map(variantProductModel -> stockConverter.convert(variantProductModel))
        .anyMatch(stockData -> StockLevelStatus.OUTOFSTOCK != stockData.getStockLevelStatus())) {
      return StockLevelStatus.INSTOCK;
    }

    return StockLevelStatus.OUTOFSTOCK;
  }

  @Required
  public void setProductService(ProductService productService) {
    this.productService = productService;
  }

  @Required
  public void setStockLevelStatusConverter(Converter<StockLevelStatus, StockData> stockLevelStatusConverter) {
    this.stockLevelStatusConverter = stockLevelStatusConverter;
  }

  @Required
  public void setStockConverter(Converter<ProductModel, StockData> stockConverter) {
    this.stockConverter = stockConverter;
  }
}
