package bt.batelco.integration.common;

import java.net.URL;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batelco.xsd.common.RequestHeaderType;
import com.batelco.xsd.common.ResponseHeaderType;

import bt.batelco.integration.bss.vo.BssPayload;

public class CommonHelper {
	
	public static final String SOURCE_SYSTEM = "Hybris";
	//TODO: move to properties files
	private static final Logger LOG = LoggerFactory.getLogger(CommonHelper.class);

	//TODO - get id from Hybris
	public static String getRandomString() {
		int length = 12;
		boolean useLetters = true;
		boolean useNumbers = true;
		return RandomStringUtils.random(length, useLetters, useNumbers);
	}

	public static XMLGregorianCalendar getDateTime(Date date) {
		XMLGregorianCalendar xmlDate = null;
		if(date == null) {
			date = new Date();
		}
		GregorianCalendar gc = new GregorianCalendar();
		gc.setTime(date); 
		try{
		   xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
		}catch(Exception e){
		   e.printStackTrace();
		} 
		
		return xmlDate;
	}
	
	public static String getSourceSystem() {
		return SOURCE_SYSTEM;
	}
	
	public static RequestHeaderType getRequestHeader() {
		RequestHeaderType requestHeader = new  RequestHeaderType();
		
		requestHeader.setTransactionID(getRandomString());
		requestHeader.setTransactionDateTime(getDateTime(new Date()));
		requestHeader.setSourceSystemName(getSourceSystem());
		
		return requestHeader;
	}
	
	public static URL getURL(String urlStr) {
		LOG.debug("URL string - " + urlStr);
		
		URL url = null;
		try {
			url = new URL(urlStr);
		}catch (Exception e) {
			LOG.error("Exception in get URL " + e.getMessage());
		}
		LOG.debug(url.toString());
		
		return url;
	}
	
	public static void updateResponseHeader(ResponseHeaderType responseHeader, BssPayload payload) {
		if(responseHeader != null && payload != null) {
			payload.setSourceSystemName(responseHeader.getSourceSystemName());
			payload.setTransactionDate(getDate(responseHeader.getTransactionDateTime()));
			payload.setTransactionId(responseHeader.getTransactionID());
			payload.setStatusCode(responseHeader.getStatusInfo().getStatusCode());
			payload.setStatusMessage(responseHeader.getStatusInfo().getStatusDesc());
		}
		
	}
	
	public static Date getDate(XMLGregorianCalendar date) {
		return date.toGregorianCalendar().getTime();
	}

}
