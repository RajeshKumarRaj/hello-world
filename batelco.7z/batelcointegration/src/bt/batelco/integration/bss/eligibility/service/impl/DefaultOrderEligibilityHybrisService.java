/**
 * 
 */
package bt.batelco.integration.bss.eligibility.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batelco.wsdl.ordereligibilityhybris.OrderEligibilityHybris;
import com.batelco.wsdl.ordereligibilityhybris.OrderEligibilityHybris_Service;
import com.batelco.wsdl.processaddress.ProcessAddressBindingQSService;
import com.batelco.wsdl.processaddress.ValidateAddressRequestMessage;
import com.batelco.wsdl.processaddress.ValidateAddressResponseMessage;
import com.batelco.xsd.common.RequestHeaderType;
import com.batelco.xsd.ordereligibilityhybris.OrderEligibilityHybrisOutputMsgType;
import com.batelco.xsd.processaddress.ValidateAddressRequestType;

import bt.batelco.integration.bss.eligibility.helper.OrderEligibilityHybrisHelper;
import bt.batelco.integration.bss.eligibility.service.OrderEligibilityHybrisService;
import bt.batelco.integration.common.CommonHelper;

import java.net.URL;

/**
 * @author admin
 *
 */
public class DefaultOrderEligibilityHybrisService implements OrderEligibilityHybrisService {
	
	private String eligibilityWsdl;
	

	private static final Logger LOG = LoggerFactory.getLogger(DefaultOrderEligibilityHybrisService.class);
	private static final String YES = "YES";

	@Override
	public String checkEligibility(String serviceId, String orderReason) {
		LOG.info("DefaultOrderEligibilityHybrisService.checkEligibility()");
		LOG.info("Data : " + serviceId + " - " + orderReason );
		//testBSSConnection();
		OrderEligibilityHybrisHelper helper = new OrderEligibilityHybrisHelper();
		OrderEligibilityHybris_Service wsdlService = new OrderEligibilityHybris_Service(CommonHelper.getURL(getEligibilityWsdl()));
		LOG.info("Service - " + wsdlService);
		OrderEligibilityHybris service = wsdlService.getOrderEligibilityHybrisSOAP();
		LOG.info("Service created - " + service);
		OrderEligibilityHybrisOutputMsgType response = service.orderEligibilityHybrisOperation(helper.getOrderEligibilityRequest(serviceId, orderReason));
		LOG.info("OrderEligibilityHybrisOutputMsgType - " + response);
		
		return helper.parseEligibilityResponse(response);
	}
	
	public void testBSSConnection() {
		
		ProcessAddressBindingQSService service = new ProcessAddressBindingQSService(CommonHelper.getURL("http://10.6.8.181:50000/IntegrationServices/GISAddressService?wsdl")); //WEB VPN
		//ProcessAddressService service = new ProcessAddressService(getURL("http://10.65.102.1:50000/IntegrationServices/GISAddressService?wsdl")); //S2S
		LOG.info("Service " + service);
		ValidateAddressRequestMessage req = new ValidateAddressRequestMessage();
		req.setRequestHeader(CommonHelper.getRequestHeader());
		req.setPayload(getAddress());
		
		//TODO: dispay req and resp xml 
		LOG.info("Address Req" + req);
		ValidateAddressResponseMessage  response = service.getProcessAddressBindingQSPort().validateAddress(req);
		LOG.info("Address Resp" + response);
	}
	
	
	
	public String getEligibilityWsdl() {
		return this.eligibilityWsdl;
	}
	
	public void setEligibilityWsdl(String eligibilityWsdl) {
		this.eligibilityWsdl = eligibilityWsdl;
	}
	
	public ValidateAddressRequestType getAddress() {
		ValidateAddressRequestType type = new ValidateAddressRequestType();
		type.setBlock("0247");
		type.setBuilding("0267");
		type.setFlat("0000");
		type.setRoad("0028");
		LOG.info("Type " + type);
		return type;
	}
	
}
