package bt.batelco.integration.bss.eligibility.helper;

import com.batelco.wsdl.processaddress.ValidateAddressResponseMessage;
import com.batelco.xsd.common.RequestHeaderType;
import com.batelco.xsd.ordereligibilityhybris.OrderEligibilityHybrisInputMsgType;
import com.batelco.xsd.ordereligibilityhybris.OrderEligibilityHybrisOutputMsgType;
import com.batelco.xsd.ordereligibilityhybris.SpecificationType;

import bt.batelco.integration.common.CommonHelper;

import com.batelco.xsd.ordereligibilityhybris.OrderEligibilityHybrisRequestMsgBody;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OrderEligibilityHybrisHelper {
	
	private static final Logger LOG = LoggerFactory.getLogger(OrderEligibilityHybrisHelper.class);
	private static final String FLAG_Y = "Y";
	private static final String FAIL = "FAIL";
	
	
	
	public OrderEligibilityHybrisInputMsgType getOrderEligibilityRequest(String serviceId, String orderReason) {
		OrderEligibilityHybrisInputMsgType request = new OrderEligibilityHybrisInputMsgType();
		request.setOrderEligibilityHybrisRequestMsgHeader(getRequestHeader());
		request.setOrderEligibilityHybrisRequestMsgBody(getRequestBody(serviceId, orderReason));
		return request;
	}
	
	public RequestHeaderType getRequestHeader() {
		RequestHeaderType requestHeader = new  RequestHeaderType();
		
		requestHeader.setTransactionID(CommonHelper.getRandomString());
		requestHeader.setTransactionDateTime(CommonHelper.getDateTime(new Date()));
		requestHeader.setSourceSystemName(CommonHelper.getSourceSystem());
		
		return requestHeader;
	}
	
	public OrderEligibilityHybrisRequestMsgBody getRequestBody(String serviceId, String orderReason) {
		OrderEligibilityHybrisRequestMsgBody requestBody = new OrderEligibilityHybrisRequestMsgBody();
		
		//Device Cash Order, Device Installment Order - order reason
		requestBody.setServiceId(serviceId);
		requestBody.setOrderReason(orderReason);
		
		/*SpecificationType specification = new SpecificationType();
		specification.setName("");
		specification.setValue("");
		
		List<SpecificationType> specifications = new ArrayList<SpecificationType>();
		specifications.add(specification);*/
		
		//requestBody.setspecifications(specifications);
		return requestBody;
	}
	
	
	public static String parseEligibilityResponse(OrderEligibilityHybrisOutputMsgType response) {
		String eligibilityFlag = FAIL;
		if(response != null 
				&& response.getOrderEligibilityHybrisResponseMsgBody() != null
				&& response.getOrderEligibilityHybrisResponseMsgBody().getSuccess() != null
				) {
			LOG.info(response.getOrderEligibilityHybrisResponseMsgBody().getSuccess());
			if(FLAG_Y.equalsIgnoreCase(response.getOrderEligibilityHybrisResponseMsgBody().getSuccess())){
				eligibilityFlag = response.getOrderEligibilityHybrisResponseMsgBody().getEligibilityFlag();
			}
		}
		LOG.info("Eligibility Flag - " + eligibilityFlag);
		return eligibilityFlag;
	}
	
}
