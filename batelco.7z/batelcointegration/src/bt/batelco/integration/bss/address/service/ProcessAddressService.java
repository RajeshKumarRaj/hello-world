/**
 * 
 */
package bt.batelco.integration.bss.address.service;

import bt.batelco.integration.bss.address.vo.ValidateAddressPayload;
import bt.batelco.integration.bss.address.vo.ValidateAddressVO;

/**
 * @author admin
 *
 */
public interface ProcessAddressService {
	
	public ValidateAddressPayload validateAddress(ValidateAddressVO address);

}
