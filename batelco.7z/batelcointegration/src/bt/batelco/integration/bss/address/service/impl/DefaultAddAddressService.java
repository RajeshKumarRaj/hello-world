package bt.batelco.integration.bss.address.service.impl;

import com.batelco.wsdl.hybrisaddress.HybrisAddress_Service;
import com.batelco.xsd.hybrisaddress.HybrisAddressOutputMsgType;

import bt.batelco.integration.bss.address.helper.AddAddressHelper;
import bt.batelco.integration.bss.address.service.AddAddressService;
import bt.batelco.integration.bss.address.vo.AddAddressPayload;
import bt.batelco.integration.bss.address.vo.AddAddressVO;
import bt.batelco.integration.common.CommonHelper;

public class DefaultAddAddressService implements AddAddressService {
	
	private String addAddressWsdl;
	

	public String getAddAddressWsdl() {
		return addAddressWsdl;
	}

	public void setAddAddressWsdl(String addAddressWsdl) {
		this.addAddressWsdl = addAddressWsdl;
	}

	@Override
	public AddAddressPayload addAddress(AddAddressVO address) {
		AddAddressPayload payload = new AddAddressPayload();//TODO - handle failure cases
		
		HybrisAddress_Service service = new HybrisAddress_Service(CommonHelper.getURL(addAddressWsdl));
		
		HybrisAddressOutputMsgType response = service.getHybrisAddressSOAP().hybrisAddressOperation(AddAddressHelper.getRequestMessage(address));
		payload = AddAddressHelper.getResponsePayload(response);
		return payload;
	}

}
