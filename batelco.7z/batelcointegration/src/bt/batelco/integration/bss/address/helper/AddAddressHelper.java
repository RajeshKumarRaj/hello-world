package bt.batelco.integration.bss.address.helper;

import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import com.batelco.xsd.common.ResponseHeaderType;
import com.batelco.xsd.hybrisaddress.HybrisAddressInputMsgType;
import com.batelco.xsd.hybrisaddress.HybrisAddressOutputMsgType;
import com.batelco.xsd.hybrisaddress.HybrisAddressRequestMsgBody;

import bt.batelco.integration.bss.address.vo.AddAddressPayload;
import bt.batelco.integration.bss.address.vo.AddAddressVO;
import bt.batelco.integration.bss.vo.BssPayload;
import bt.batelco.integration.common.CommonHelper;

public class AddAddressHelper {
	
	private static final String MEDIA_TYPE = "Fiber";
	private static final String ACTION = "Insert";
	
	public static HybrisAddressInputMsgType getRequestMessage(AddAddressVO address) {
		HybrisAddressInputMsgType request = new HybrisAddressInputMsgType();
		request.setHybrisAddressRequestMsgHeader(CommonHelper.getRequestHeader());
		HybrisAddressRequestMsgBody reqBody = getHybrisAddressRequestMsgBody(address);
		request.setHybrisAddressRequestMsgBody(reqBody);
		
		return request;
	}

	private static HybrisAddressRequestMsgBody getHybrisAddressRequestMsgBody(AddAddressVO address) {
		HybrisAddressRequestMsgBody body = new HybrisAddressRequestMsgBody();
		body.setLegalFlag("N");
		body.setAccountId(address.getAccountId());
		body.setBlockArabicLine2(address.getBlock());
		body.setBuildingEnglishLine2(address.getBuilding());
		body.setBuildingName(address.getBuildingName());
		body.setBuildingCharacter(address.getBuildingCharacter());
		body.setCategory("National");
		body.setFlatEnglishLine1(address.getFlat());
		body.setGISAddressId(address.getGisAddressId());
		body.setAddressStatus("Valid");
		body.setRoadArabicLine1(address.getRoad());
		body.setSource("Hybris");
		
		//TODO - check for these fields & put static values in properties file.
		body.setDomain("");
		body.setExchange("");
		body.setMediaType(MEDIA_TYPE);
		body.setAction(ACTION);
		
		body.setCountry(address.getCountry());
		body.setCity(address.getCity());
		//body.setAddressId(body.getAddressId());
		
		return body;
	}

	public static AddAddressPayload getResponsePayload(HybrisAddressOutputMsgType response) {
		AddAddressPayload payload = new AddAddressPayload();
		
		if(response != null && response.getHybrisAddressResponseMsgHeader() != null) {
			CommonHelper.updateResponseHeader(response.getHybrisAddressResponseMsgHeader(), payload);
		}
		
		if( response != null 
				&& response.getHybrisAddressResponseMsgBody() != null
				&& response.getHybrisAddressResponseMsgBody().getSuccess() != null){
			payload.setSuccess("Y".equalsIgnoreCase(response.getHybrisAddressResponseMsgBody().getSuccess()));
			payload.setSiebelRowId(response.getHybrisAddressResponseMsgBody().getRowID());
		}
		
		return payload;
	}
	

}
