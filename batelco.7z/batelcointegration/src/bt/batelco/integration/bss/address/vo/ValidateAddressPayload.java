package bt.batelco.integration.bss.address.vo;

import bt.batelco.integration.bss.vo.BssPayload;

public class ValidateAddressPayload extends BssPayload{
	
	private String gisAddressId;

	public String getGisAddressId() {
		return gisAddressId;
	}

	public void setGisAddressId(String gisAddressId) {
		this.gisAddressId = gisAddressId;
	}
	

}
