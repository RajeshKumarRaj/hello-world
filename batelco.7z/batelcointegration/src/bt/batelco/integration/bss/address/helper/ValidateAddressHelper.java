package bt.batelco.integration.bss.address.helper;

import com.batelco.wsdl.processaddress.ValidateAddressRequestMessage;
import com.batelco.wsdl.processaddress.ValidateAddressResponseMessage;
import com.batelco.xsd.processaddress.ValidateAddressRequestType;

import bt.batelco.integration.bss.address.vo.ValidateAddressPayload;
import bt.batelco.integration.bss.address.vo.ValidateAddressVO;
import bt.batelco.integration.common.CommonHelper;

public class ValidateAddressHelper {
	
	public static ValidateAddressRequestMessage getRequestMessage(ValidateAddressVO addressVo) {
		
		ValidateAddressRequestMessage request = new ValidateAddressRequestMessage();
		request.setRequestHeader(CommonHelper.getRequestHeader());
		ValidateAddressRequestType payload = new ValidateAddressRequestType();
		payload.setBlock(addressVo.getBlock());
		payload.setBuilding(addressVo.getBuilding());
		payload.setFlat(addressVo.getFlat());
		payload.setRoad(addressVo.getRoad());
		request.setPayload(payload);
		return request;
	}
	
	public static ValidateAddressPayload getResponsePayload(ValidateAddressResponseMessage response) {
		ValidateAddressPayload payload = new ValidateAddressPayload();
		
		if(response != null && response.getResponseHeader() != null) {
			CommonHelper.updateResponseHeader(response.getResponseHeader(), payload);
		}
		
		if(response != null 
				&& response.getPayload() != null
				&& response.getPayload().getAddressID() != null )
		
		payload.setGisAddressId(response.getPayload().getAddressID());
		return payload;
	}
	
}
