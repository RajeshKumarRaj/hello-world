package bt.batelco.integration.bss.address.vo;

import bt.batelco.integration.bss.vo.BssPayload;

public class AddAddressPayload extends BssPayload {

	private boolean isSuccess;
	private String siebelRowId;

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getSiebelRowId() {
		return siebelRowId;
	}

	public void setSiebelRowId(String siebelRowId) {
		this.siebelRowId = siebelRowId;
	}
	
	
}
