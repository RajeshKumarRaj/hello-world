package bt.batelco.integration.bss.address.vo;

public class ValidateAddressVO {

	private String road;
	private String building;
	private String flat;
	private String block;

	public ValidateAddressVO(String road, String building, String flat, String block) {
		this.road = road;
		this.building = building;
		this.flat = flat;
		this.block = block;
	}

	public ValidateAddressVO() {
		super();
	}

	public String getRoad() {
		return road;
	}

	public void setRoad(String road) {
		this.road = road;
	}

	public String getBuilding() {
		return building;
	}

	public void setBuilding(String building) {
		this.building = building;
	}

	public String getFlat() {
		return flat;
	}

	public void setFlat(String flat) {
		this.flat = flat;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

}
