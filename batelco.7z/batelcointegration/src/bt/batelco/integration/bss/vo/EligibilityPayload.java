package bt.batelco.integration.bss.vo;

public class EligibilityPayload extends BssPayload{

	private boolean isEligible;

	public boolean isEligible() {
		return isEligible;
	}

	public void setEligible(boolean isEligible) {
		this.isEligible = isEligible;
	}
	
	
}
