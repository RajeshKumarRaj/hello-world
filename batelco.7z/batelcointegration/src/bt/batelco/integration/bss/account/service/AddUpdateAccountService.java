package bt.batelco.integration.bss.account.service;

import bt.batelco.integration.bss.account.vo.AccountVO;
import bt.batelco.integration.bss.account.vo.AddUpdateAccountPayload;

public interface AddUpdateAccountService {
	AddUpdateAccountPayload addUpdateAccount(AccountVO account);
}
