package bt.batelco.integration.bss.account.helper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.batelco.xsd.createcustomer.Account;
import com.batelco.xsd.createcustomer.AccountContact;
import com.batelco.xsd.createcustomer.CreateOrUpdateAccountRequest;
import com.batelco.xsd.createcustomer.CreateOrUpdateAccountResponse;
import com.batelco.xsd.createcustomer.CreateOrUpdateRequestBodyType;
import com.batelco.xsd.createcustomer.CreateOrUpdateResponseBodyType;
import com.batelco.xsd.createcustomer.CutAddress;
import com.batelco.xsd.createcustomer.ListOfAccountContact;
import com.batelco.xsd.createcustomer.ListOfAccountInterfaceIo;
import com.batelco.xsd.createcustomer.ListOfCutAddress;

import bt.batelco.integration.bss.account.vo.AccountVO;
import bt.batelco.integration.bss.account.vo.AddUpdateAccountPayload;
import bt.batelco.integration.common.CommonHelper;

public class AddUpdateAccountHelper {
	
	private static final String ACCOUNT_CLASS = "Customer";
	private static final String CUSTOMER_SEGMENT = "Mass - MSS";
	private static final String TYPE = "RESIDENTIAL - RES";
	private static final String STATUS = "Prospect";

	public static CreateOrUpdateAccountRequest createRequest(AccountVO account) {
		CreateOrUpdateAccountRequest request = new CreateOrUpdateAccountRequest();
		request.setCreateOrUpdateAccountRequestMsgHeader(CommonHelper.getRequestHeader());
		request.setCreateOrUpdateAccountRequestMsgBody(createRequestBody(account));
		
		return request;
	}
	
	// populate request body from account VO
	public static CreateOrUpdateRequestBodyType createRequestBody(AccountVO accountVo) {
		CreateOrUpdateRequestBodyType requestBody = new CreateOrUpdateRequestBodyType();
		
		// accountLo
		ListOfAccountInterfaceIo accountlo = new ListOfAccountInterfaceIo();
		// account
		Account account = new Account();
		account.setName(accountVo.getFirstName()+" "+accountVo.getLastName());
		account.setIdentificationType(accountVo.getIdType());
		account.setIdentificationNumber(accountVo.getCprId());
		account.setMainPhoneNumber(accountVo.getPhone());
		// TODO - static parameters to be set in properties file.
		account.setAccountClass(ACCOUNT_CLASS);
		account.setCustomersegment(CUSTOMER_SEGMENT);
		account.setType(TYPE);
		account.setStatus(STATUS);
		
		// address
		ListOfCutAddress addressList = new ListOfCutAddress();
		CutAddress address = new CutAddress();
		address.setCountry(accountVo.getCountry());
		address.setCity(accountVo.getCity());
		address.setFlat(accountVo.getFlat());
		address.setBuilding(accountVo.getBuilding());
		address.setRoad(accountVo.getRoad());
		address.setBlock(accountVo.getBlock());
		addressList.getCutAddress().add(address);
		
		// contact
		ListOfAccountContact contactList = new ListOfAccountContact();
		AccountContact contact = new AccountContact();
		contact.setMVGBTIdentificationType(accountVo.getIdType());
		contact.setMVGBTIdentificationNumber(accountVo.getCprId());	
		contact.setMVGEmailAddress(accountVo.getEmail());
		contact.setMVGFirstName(accountVo.getFirstName());
		contact.setMVGLastName(accountVo.getLastName());
		contact.setMVGBTNationality(accountVo.getCountry());
		contact.setMVGDateOfBirth(getSiebelDate(accountVo.getDob()));
		//contact.setMVGDateOfBirth("1998-10-02T08:41:56");
		contactList.getAccountContact().add(contact);
		// set address & contact to account
		account.setListOfCutAddress(addressList);
		account.setListOfAccountContact(contactList);
		// set account to accountLo
		accountlo.getAccount().add(account);
		//set accountLo to request body
		requestBody.setListOfAccountInterfaceIo(accountlo);
		
		return requestBody;
	}

	public static AddUpdateAccountPayload getResponsePayload(CreateOrUpdateAccountResponse response) {
		AddUpdateAccountPayload accountPayload = null;
		if(response != null) {
			if(response.getCreateOrUpdateAccountResponseMsgBody() != null) {
				CommonHelper.updateResponseHeader(response.getCreateOrUpdateAccountResponseMsgHeader(), accountPayload);
				CreateOrUpdateResponseBodyType responseBody = response.getCreateOrUpdateAccountResponseMsgBody();
				if(responseBody != null) {
					accountPayload = createResponsePayload(responseBody);
				}
			}
		}
		return accountPayload;
	}
	
	// populate response payment from response body
	public static AddUpdateAccountPayload createResponsePayload(CreateOrUpdateResponseBodyType responseBody) {
		AddUpdateAccountPayload accountPayload = new AddUpdateAccountPayload();
		
		accountPayload.setSuccess("Y".equalsIgnoreCase(responseBody.getSuccessFlag()));
		accountPayload.setAccountId(responseBody.getAccountSpcNumber());
		//accountPayload.setAccountId("1-1GHDSL13");
		accountPayload.setAccountType(responseBody.getAccountType());
		accountPayload.setIdType(responseBody.getIDType());
		accountPayload.setIdNumber(responseBody.getIDNumber());
		accountPayload.setSegment(responseBody.getSegment());
		accountPayload.setClassName(responseBody.getClassName());
		//accountPayload.setSubSegment(responseBody.getSubSegment());
		//responseBody.getVATExemptFlag();
		//responseBody.getVATExemptStartDt();
		//responseBody.getVATExemptEndDt();
		//accountPayload.set
		return accountPayload;
	}
	
	private static String getSiebelDate(String date) {
		String oldFormat = "dd/MM/yyyy";
	    String newFormat = "yyyy-MM-dd'T'HH:mm:ss";
	    String formattedDate = null;
	    SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
	    try {
	        Date newDate = sdf.parse(date);
	        sdf.applyPattern(newFormat);
	        formattedDate = sdf.format(newDate);
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
	    return formattedDate;
	}
	
}
