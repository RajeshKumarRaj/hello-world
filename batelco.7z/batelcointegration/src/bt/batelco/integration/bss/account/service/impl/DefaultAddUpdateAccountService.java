package bt.batelco.integration.bss.account.service.impl;

import com.batelco.wsdl.createcustomer.CreateOrUpdateAccountService;
import com.batelco.xsd.createcustomer.CreateOrUpdateAccountResponse;

import bt.batelco.integration.bss.account.helper.AddUpdateAccountHelper;
import bt.batelco.integration.bss.account.service.AddUpdateAccountService;
import bt.batelco.integration.bss.account.vo.AccountVO;
import bt.batelco.integration.bss.account.vo.AddUpdateAccountPayload;
import bt.batelco.integration.common.CommonHelper;

public class DefaultAddUpdateAccountService implements AddUpdateAccountService {
	
	private String addUpdateAccountWsdl;

	@Override
	public AddUpdateAccountPayload addUpdateAccount(AccountVO account) {
		AddUpdateAccountPayload accountPayload = null;
		CreateOrUpdateAccountService accountService = new CreateOrUpdateAccountService(CommonHelper.getURL(addUpdateAccountWsdl));
		CreateOrUpdateAccountResponse response = accountService.getCreateCustomerSOAP().createOrUpdateAccount(AddUpdateAccountHelper.createRequest(account));
		accountPayload = AddUpdateAccountHelper.getResponsePayload(response);
		
		return accountPayload;
	}

	public String getAddUpdateAccountWsdl() {
		return addUpdateAccountWsdl;
	}

	public void setAddUpdateAccountWsdl(String addUpdateAccountWsdl) {
		this.addUpdateAccountWsdl = addUpdateAccountWsdl;
	}
	
}
