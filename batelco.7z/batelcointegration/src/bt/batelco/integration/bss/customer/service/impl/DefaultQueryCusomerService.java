package bt.batelco.integration.bss.customer.service.impl;

import bt.batelco.integration.bss.customer.helper.QueryCustomerInfoHelper;
import bt.batelco.integration.bss.customer.service.QueryCustomerService;
import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoPayload;
import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoVO;
import bt.batelco.integration.common.CommonHelper;

import com.batelco.wsdl.querycustomerinformation.QueryAccountDetailsResponseMessage;
import com.batelco.wsdl.querycustomerinformation.QueryCustomerInformationBindingQSService;

public class DefaultQueryCusomerService implements QueryCustomerService {

	private String queryCustomerInfoWsdl;
	
	@Override
	public QueryCustomerInfoPayload getCustomerInfo(QueryCustomerInfoVO customerVO) {
		QueryCustomerInfoPayload customerPayload = null;
		
		QueryCustomerInformationBindingQSService customerInfoService = new QueryCustomerInformationBindingQSService(CommonHelper.getURL(getQueryCustomerInfoWsdl()));
		QueryAccountDetailsResponseMessage response = customerInfoService.getQueryCustomerInformationBindingQSPort()
																		.queryAccountDetails(QueryCustomerInfoHelper.createRequest(customerVO));
		customerPayload = QueryCustomerInfoHelper.getResponsePayload(response);
		
		return customerPayload;
	}

	public String getQueryCustomerInfoWsdl() {
		return queryCustomerInfoWsdl;
	}

	public void setQueryCustomerInfoWsdl(String queryCustomerInfoWsdl) {
		this.queryCustomerInfoWsdl = queryCustomerInfoWsdl;
	}
	
}
