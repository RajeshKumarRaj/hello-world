package bt.batelco.integration.bss.customer.service;

import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoPayload;
import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoVO;

public interface QueryCustomerService {
	
	/**
	 * 
	 * @param customerVO
	 * @return
	 */
	QueryCustomerInfoPayload getCustomerInfo(QueryCustomerInfoVO customerVO);
	
}
