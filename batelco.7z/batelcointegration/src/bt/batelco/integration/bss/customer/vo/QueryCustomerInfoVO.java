package bt.batelco.integration.bss.customer.vo;

public class QueryCustomerInfoVO {
	private String identificationType;
	private String identificationNumber;
	
	public String getIdentificationType() {
		return identificationType;
	}
	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}
	
	public String getIdentificationNumber() {
		return identificationNumber;
	}
	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}
	
	@Override
	public String toString() {
		return "QueryCustomerInfoVO [identificationType=" + identificationType + ", identificationNumber="
				+ identificationNumber + "]";
	}
	
}
