/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 23, 2020 8:44:23 PM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.facades.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBatelcoFacadesConstants
{
	public static final String EXTENSIONNAME = "batelcofacades";
	
	protected GeneratedBatelcoFacadesConstants()
	{
		// private constructor
	}
	
	
}
