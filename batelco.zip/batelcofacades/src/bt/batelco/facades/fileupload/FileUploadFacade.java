package bt.batelco.facades.fileupload;

import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

public interface FileUploadFacade {

  /**
   * Attaches the acquisition form to the given cart entry.
   *
   * @param file        the <i>acquisition form</i> file
   * @param inputStream the input stream of <i>acquisition form</i> file
   * @param entryNumber the number of the entry
   * @throws IllegalArgumentException, MaxUploadSizeExceededException
   */
  void attachAcquisitionForm(MultipartFile file, InputStream inputStream, int entryNumber);

  /**
   * Attaches CPR front to cart.
   *
   * @param file        the <i>CPR front</i> file
   * @param inputStream the input stream of <i>CPR front</i> file
   * @throws IllegalArgumentException, MaxUploadSizeExceededException
   */
  void attachCprFront(MultipartFile file, InputStream inputStream);

  /**
   * Attaches CPR back to cart.
   *
   * @param file        the <i>CPR back</i> file
   * @param inputStream the input stream of <i>CPR back</i> file
   * @throws IllegalArgumentException, MaxUploadSizeExceededException
   */
  void attachCprBack(MultipartFile file, InputStream inputStream);

  /**
   * Attaches payment evidence to order.
   *
   * @param file        the <i>payment evidence</i> file
   * @param inputStream the input stream of <i>payment evidence</i> file
   * @throws IllegalArgumentException, MaxUploadSizeExceededException
   */
  void attachPaymentEvidence(MultipartFile file, InputStream inputStream);

  /**
   * Gets all Acquisition Form mime types
   *
   * @return all Acquisition Form mime types
   */
  String getAllAcquisitionFormMimeTypes();

  /**
   * Gets all CPR mime types
   *
   * @return all CPR mime types
   */
  String getAllCprMimeTypes();

  /**
   * Gets Acquisition Form max size
   *
   * @return Acquisition Form max size
   */
  Double getAcquisitionFormMaxSize();

  /**
   * Gets CPR max size
   *
   * @return CPR max size
   */
  Double getCprMaxSize();

  /**
   * Gets all Payment Evidence mime types
   *
   * @return all Payment Evidence mime types
   */
  String getAllPaymentEvidenceMimeTypes();

  /**
   * Gets Payment Evidence max size
   *
   * @return Payment Evidence max size
   */
  Double getPaymentEvidenceMaxSize();
}
