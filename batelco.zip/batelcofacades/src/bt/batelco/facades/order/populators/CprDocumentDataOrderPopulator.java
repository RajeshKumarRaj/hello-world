package bt.batelco.facades.order.populators;

import de.hybris.platform.commercefacades.order.data.AbstractOrderData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.AbstractOrderModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import bt.batelco.facades.order.data.DocumentData;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

public class CprDocumentDataOrderPopulator implements Populator<AbstractOrderModel, AbstractOrderData> {

    @Override
    public void populate(AbstractOrderModel source, AbstractOrderData target) throws ConversionException {
        validateParameterNotNullStandardMessage("source", source);
        validateParameterNotNullStandardMessage("target", target);

        if (source.getCprFront() != null) {
            populateCprFrontData(source.getCprFront(), target);
        }

        if (source.getCprBack() != null) {
            populateCprBackData(source.getCprBack(), target);
        }

    }

    private void populateCprBackData(MediaModel cprBack, AbstractOrderData target) {
        target.setUploadedCprBack(createDocumentData(cprBack.getRealFileName(), cprBack.getSize()));
    }

    private void populateCprFrontData(MediaModel cprFront, AbstractOrderData target) {
        target.setUploadedCprFront(createDocumentData(cprFront.getRealFileName(), cprFront.getSize()));
    }

    private DocumentData createDocumentData(String realFileName, Long size) {
        DocumentData documentData = new DocumentData();
        documentData.setFileName(realFileName);
        documentData.setFileSize(size);
        return documentData;
    }
}
