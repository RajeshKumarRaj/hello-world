package bt.batelco.facades.order.populators;

import de.hybris.platform.commercefacades.order.data.OrderEntryData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.springframework.beans.factory.annotation.Required;

import bt.batelco.core.model.BatelcoPaymentInfoModel;
import bt.batelco.facades.order.data.BatelcoPaymentInfoData;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * Populates Batelco Payment Info for target {@link OrderEntryData} based on {@link AbstractOrderEntryModel} value.
 */
public class PaymentInfoOrderEntryPopulator implements Populator<AbstractOrderEntryModel, OrderEntryData> {
  private Converter<BatelcoPaymentInfoModel, BatelcoPaymentInfoData> batelcoPaymentInfoConverter;

  @Override
  public void populate(AbstractOrderEntryModel source, OrderEntryData target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    final BatelcoPaymentInfoModel paymentInfo = source.getPaymentInfo();
    if (paymentInfo != null) {
      target.setPaymentInfo(batelcoPaymentInfoConverter.convert(paymentInfo));
    }
  }

  @Required
  public void setBatelcoPaymentInfoConverter(
      Converter<BatelcoPaymentInfoModel, BatelcoPaymentInfoData> batelcoPaymentInfoConverter) {
    this.batelcoPaymentInfoConverter = batelcoPaymentInfoConverter;
  }
}