package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.commercefacades.product.converters.populator.ProductDescriptionPopulator;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;

public class BatelcoProductDescriptionPopulator<SOURCE extends ProductModel, TARGET extends ProductData>
    extends ProductDescriptionPopulator<SOURCE, TARGET> {

  @Override
  protected Object getProductAttribute(final ProductModel productModel, final String attribute) {
    final Object value = getModelService().getAttributeValue(productModel, attribute);
    if (value == null && productModel instanceof TmaPoVariantModel) {
      final ProductModel baseProduct = ((TmaPoVariantModel) productModel).getTmaBasePo();
      if (baseProduct != null) {
        return getProductAttribute(baseProduct, attribute);
      }
    }
    return value;
  }
}
