package bt.batelco.facades.product.populators;

import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaSimpleProductOfferingModel;
import de.hybris.platform.commercefacades.product.converters.populator.ProductGalleryImagesPopulator;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.media.MediaContainerModel;
import de.hybris.platform.core.model.product.ProductModel;

import java.util.List;

public class BatelcoProductGalleryImagesPopulator<SOURCE extends ProductModel, TARGET extends ProductData>
    extends ProductGalleryImagesPopulator<SOURCE, TARGET> {

  @Override
  protected Object getProductAttribute(final ProductModel productModel, final String attribute) {
    final Object value = getModelService().getAttributeValue(productModel, attribute);
    if (value == null && productModel instanceof TmaPoVariantModel) {
      final ProductModel baseProduct = ((TmaPoVariantModel) productModel).getTmaBasePo();
      if (baseProduct != null) {
        return getModelService().getAttributeValue(baseProduct, attribute);
      }
    }

    if (value == null && productModel instanceof TmaSimpleProductOfferingModel) {
      TmaPoVariantModel defaultTmaPoVariant = ((TmaSimpleProductOfferingModel) productModel).getDefaultTmaPoVariant();
      if (defaultTmaPoVariant != null) {
        return getModelService().getAttributeValue(defaultTmaPoVariant, attribute);
      }
    }

    return value;
  }

  protected void collectMediaContainers(final ProductModel productModel, final List<MediaContainerModel> list) {
    final List<MediaContainerModel> galleryImages =
        (List<MediaContainerModel>) getProductAttribute(productModel, ProductModel.GALLERYIMAGES);

    if (galleryImages != null) {
      for (final MediaContainerModel galleryImage : galleryImages) {
        if (!list.contains(galleryImage)) {
          list.add(galleryImage);
        }
      }

      if (galleryImages.isEmpty() && productModel instanceof TmaPoVariantModel) {
        collectMediaContainers(((TmaPoVariantModel) productModel).getTmaBasePo(), list);
      }
    }
  }
}
