package bt.batelco.facades.product.impl;

import de.hybris.platform.acceleratorservices.urlencoder.UrlEncoderService;
import de.hybris.platform.acceleratorservices.urlresolver.SiteBaseUrlResolutionService;
import de.hybris.platform.b2ctelcofacades.product.impl.DefaultTmaProductOfferFacade;
import de.hybris.platform.b2ctelcoservices.model.TmaPoVariantModel;
import de.hybris.platform.b2ctelcoservices.model.TmaProductOfferingModel;
import de.hybris.platform.commerceservices.url.UrlResolver;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.site.BaseSiteService;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Required;

import bt.batelco.facades.product.BatelcoTmaProductOfferFacade;

public class DefaultBatelcoTmaProductOfferFacade extends DefaultTmaProductOfferFacade implements
                                                                                      BatelcoTmaProductOfferFacade {

  private UrlResolver<ProductModel> productModelUrlResolver;
  private BaseSiteService baseSiteService;
  private SiteBaseUrlResolutionService siteBaseUrlResolutionService;
  private UrlEncoderService urlEncoderService;

  @Override
  public String getCanonicalLink(TmaProductOfferingModel productModel) {
    String generatedUrl = null;
    if (productModel instanceof TmaPoVariantModel) {
      generatedUrl = productModelUrlResolver.resolve(((TmaPoVariantModel) productModel).getTmaBasePo());
    }

    if (StringUtils.isNotEmpty(generatedUrl)) {
      return siteBaseUrlResolutionService.
          getWebsiteUrlForSite(baseSiteService.getCurrentBaseSite(), urlEncoderService.getUrlEncodingPattern(), true,
                               generatedUrl);
    }

    return null;
  }

  @Required
  public void setProductModelUrlResolver(UrlResolver<ProductModel> productModelUrlResolver) {
    this.productModelUrlResolver = productModelUrlResolver;
  }

  @Required
  public void setBaseSiteService(BaseSiteService baseSiteService) {
    this.baseSiteService = baseSiteService;
  }

  @Required
  public void setSiteBaseUrlResolutionService(
      SiteBaseUrlResolutionService siteBaseUrlResolutionService) {
    this.siteBaseUrlResolutionService = siteBaseUrlResolutionService;
  }

  @Required
  public void setUrlEncoderService(UrlEncoderService urlEncoderService) {
    this.urlEncoderService = urlEncoderService;
  }
}
