package bt.batelco.facades.product.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlType(propOrder = {"title", "link", "description", "products"})
public class Channel
{
    private String link;
    private String description;
    private String title;
    private List<ExportProductDTO> products;

    @XmlElement(name = "link")
    public void setLink (String link)
    {
        this.link = link;
    }

    @XmlElement(name = "description")
    public void setDescription (String description)
    {
        this.description = description;
    }

    @XmlElement(name = "title")
    public void setTitle (String title)
    {
        this.title = title;
    }

    @XmlElement(name = "item")
    public void setProducts(List<ExportProductDTO> products) {
        this.products = products;
    }

    public void add(ExportProductDTO product) {
        if (this.products == null) {
            this.products = new ArrayList<ExportProductDTO>();
        }
        this.products.add(product);
    }

    @Override
    public String toString()
    {
        return "ClassPojo [link = "+link+", description = "+description+", title = "+title+"]";
    }

    public String getLink ()
    {
        return link;
    }

    public String getDescription() {
        return description;
    }

    public String getTitle() {
        return title;
    }

    public List<ExportProductDTO> getProducts() {
        return products;
    }
}