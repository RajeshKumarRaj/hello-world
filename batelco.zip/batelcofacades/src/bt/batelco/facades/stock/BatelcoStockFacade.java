package bt.batelco.facades.stock;

import de.hybris.platform.basecommerce.enums.StockLevelStatus;
import de.hybris.platform.commercefacades.product.data.StockData;

/**
 * Manage batelco stock facade
 */
public interface BatelcoStockFacade {
  /**
   * When out of stock or low stock for base product, check if all other variants are out of stock
   * If the product is no longer visible to the customergroup, then it will be marked as out of stock
   *
   * @param prodCode product code
   * @return stock data
   */
  StockData evaluateStockLevel(String prodCode, StockLevelStatus defaultLevelStatus);


}
