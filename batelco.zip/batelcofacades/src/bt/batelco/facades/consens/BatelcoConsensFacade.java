package bt.batelco.facades.consens;

import de.hybris.platform.commercefacades.consent.ConsentFacade;
import de.hybris.platform.commercefacades.consent.data.ConsentTemplateData;
import de.hybris.platform.commerceservices.model.consent.ConsentTemplateModel;

/**
 * Facade interface for performing various consent operations.
 */
public interface BatelcoConsensFacade extends ConsentFacade {

  /**
   * Gives consent for the specified <code>consentTemplateId</code> and <code>consentTemplateVersion</code>, the
   * current base site and current user. If no Consent is found for the specified Consent Template, or if a Consent
   * exists but is withdrawn (i.e. the withdrawal date is not null), a new Consent is created with the current date set
   * to <code>consentGivenDate</code> attribute.
   *
   * @param consentTemplateId      the id of the consent template to give the consent for. Should be a valid id for a
   *                               {@link ConsentTemplateModel}.
   * @param consentTemplateVersion the version of the consent template to give the consent for
   * @param customerUid            customer uid
   * @throws de.hybris.platform.servicelayer.exceptions.ModelNotFoundException       if no ConsentTemplate
   *                                                                                 with the specified
   *                                                                                 <code>consentTemplateId</code>
   *                                                                                 and <code>consentTemplateVersion</code>
   *                                                                                 was found
   * @throws de.hybris.platform.servicelayer.exceptions.AmbiguousIdentifierException if multiple ConsentTemplate
   *                                                                                 entities were found
   *                                                                                 for the the specified
   *                                                                                 <code>consentTemplateId</code>
   *                                                                                 and <code>consentTemplateVersion</code>
   * @throws bt.batelco.facades.exception.FacadeException                            if a consent was
   *                                                                                 already given
   */
  void giveConsent(final String consentTemplateId, Integer consentTemplateVersion, final String customerUid);

  /**
   * Get terms and conditions consent
   */
  ConsentTemplateData getTermsAndConditionsConsentTemplateData();

}
