package bt.batelco.facades.populators;

import de.hybris.platform.acceleratorservices.sitemap.data.SiteMapUrlData;
import de.hybris.platform.acceleratorservices.sitemap.populators.ContentPageModelToSiteMapUrlDataPopulator;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

public class BatelcoContentPageModelToSiteMapUrlDataPopulator extends ContentPageModelToSiteMapUrlDataPopulator {

  private static final String SLASH = "/";

  @Override
  public void populate(final ContentPageModel contentPageModel, final SiteMapUrlData siteMapUrlData)
      throws ConversionException {
    String url = contentPageModel.getLabel();
    if (url != null) {
      siteMapUrlData.setLoc(url.startsWith(SLASH) ? url : SLASH + url);
    }
  }
}