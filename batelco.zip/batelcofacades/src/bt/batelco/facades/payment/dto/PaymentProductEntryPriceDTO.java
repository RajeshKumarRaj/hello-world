package bt.batelco.facades.payment.dto;

/**
 * Holds product entry price info.
 */
public class PaymentProductEntryPriceDTO {
  private String downpayment;
  private String advance;
  private String vat;

  public String getDownpayment() {
    return downpayment;
  }

  public void setDownpayment(String downpayment) {
    this.downpayment = downpayment;
  }

  public String getAdvance() {
    return advance;
  }

  public void setAdvance(String advance) {
    this.advance = advance;
  }

  public String getVat() {
    return vat;
  }

  public void setVat(String vat) {
    this.vat = vat;
  }
}
