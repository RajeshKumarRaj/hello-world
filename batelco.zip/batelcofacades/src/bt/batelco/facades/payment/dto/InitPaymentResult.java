package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InitPaymentResult {


	 @JsonProperty
	 private String PaymentID;
	 @JsonProperty
	 private String PaymentRedirectURL;
	 @JsonProperty
	 private String Status;


	 // Getter Methods 

	 public String getPaymentID() {
	  return PaymentID;
	 }

	 public String getPaymentRedirectURL() {
	  return PaymentRedirectURL;
	 }

	 public String getStatus() {
	  return Status;
	 }

	 // Setter Methods 

	 public void setPaymentID(String PaymentID) {
	  this.PaymentID = PaymentID;
	 }

	 public void setPaymentRedirectURL(String PaymentRedirectURL) {
	  this.PaymentRedirectURL = PaymentRedirectURL;
	 }

	 public void setStatus(String Status) {
	  this.Status = Status;
	 }

	
}
