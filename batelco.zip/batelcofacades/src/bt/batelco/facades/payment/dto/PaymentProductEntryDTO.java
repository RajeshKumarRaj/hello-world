package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import org.springframework.beans.factory.annotation.Required;

/**
 * Holds payment product entry info.
 */
public class PaymentProductEntryDTO {
  private String entryId;
  private String name;
  @JsonProperty("amounts")
  private PaymentProductEntryPriceDTO entryPrice;

  public String getEntryId() {
    return entryId;
  }

  public void setEntryId(String entryId) {
    this.entryId = entryId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public PaymentProductEntryPriceDTO getEntryPrice() {
    return entryPrice;
  }

  @Required
  public void setEntryPrice(PaymentProductEntryPriceDTO entryPrice) {
    this.entryPrice = entryPrice;
  }
}
