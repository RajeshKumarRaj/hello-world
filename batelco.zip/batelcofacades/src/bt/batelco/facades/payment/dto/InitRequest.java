package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InitRequest {

	@JsonProperty("InitPayment")
	private InitPayment initPayment;

	public InitPayment getInitPayment() {
		return initPayment;
	}

	public void setInitPayment(InitPayment initPayment) {
		this.initPayment = initPayment;
	}
	
}
