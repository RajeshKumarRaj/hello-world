package bt.batelco.facades.payment.dto;

import java.util.List;

/**
 * Holds order payment details data.
 */
public class PaymentDetailsDTO {
  private String cardType;
  private String totalAmount;
  private List<PaymentDetailsItemDTO> items;
  private PaymentCustomerDTO customer;

  public String getCardType() {
    return cardType;
  }

  public void setCardType(String cardType) {
    this.cardType = cardType;
  }

  public String getTotalAmount() {
    return totalAmount;
  }

  public void setTotalAmount(String totalAmount) {
    this.totalAmount = totalAmount;
  }

  public List<PaymentDetailsItemDTO> getItems() {
    return items;
  }

  public void setItems(List<PaymentDetailsItemDTO> items) {
    this.items = items;
  }

  public PaymentCustomerDTO getCustomer() {
    return customer;
  }

  public void setCustomer(PaymentCustomerDTO customer) {
    this.customer = customer;
  }
}
