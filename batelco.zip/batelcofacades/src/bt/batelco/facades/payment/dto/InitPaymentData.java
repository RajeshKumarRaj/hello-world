package bt.batelco.facades.payment.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InitPaymentData {

	private String cardType;
	private String channel;
	private String username;
	private String password;
	private String customerId;
	private String customerIdType;
	private String customerName;
	private String paymentConfig;
	private String paymentId;
	private String paymentMode;
	private String paymentType;
	private String paymentSource;
	private double paymentTotalAmount;
	private String redirectErrorURL;
	private String redirectURL;
	private String transUniqueID;
	private String customerIP;
	private String isLoggedIn;
	
	@JsonProperty("PaymentCart")
	private PaymentCart paymentCart;

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerIdType() {
		return customerIdType;
	}

	public void setCustomerIdType(String customerIdType) {
		this.customerIdType = customerIdType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPaymentConfig() {
		return paymentConfig;
	}

	public void setPaymentConfig(String paymentConfig) {
		this.paymentConfig = paymentConfig;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentSource() {
		return paymentSource;
	}

	public void setPaymentSource(String paymentSource) {
		this.paymentSource = paymentSource;
	}

	public double getPaymentTotalAmount() {
		return paymentTotalAmount;
	}

	public void setPaymentTotalAmount(double paymentTotalAmount) {
		this.paymentTotalAmount = paymentTotalAmount;
	}

	public String getRedirectErrorURL() {
		return redirectErrorURL;
	}

	public void setRedirectErrorURL(String redirectErrorURL) {
		this.redirectErrorURL = redirectErrorURL;
	}

	public String getRedirectURL() {
		return redirectURL;
	}

	public void setRedirectURL(String redirectURL) {
		this.redirectURL = redirectURL;
	}

	public String getTransUniqueID() {
		return transUniqueID;
	}

	public void setTransUniqueID(String transUniqueID) {
		this.transUniqueID = transUniqueID;
	}

	public String getCustomerIP() {
		return customerIP;
	}

	public void setCustomerIP(String customerIP) {
		this.customerIP = customerIP;
	}

	public String getIsLoggedIn() {
		return isLoggedIn;
	}

	public void setIsLoggedIn(String isLoggedIn) {
		this.isLoggedIn = isLoggedIn;
	}

	public PaymentCart getPaymentCart() {
		return paymentCart;
	}

	public void setPaymentCart(PaymentCart paymentCart) {
		this.paymentCart = paymentCart;
	}
	
	
	
}
