package bt.batelco.facades.payment.populators;

import org.apache.commons.lang3.StringUtils;

import bt.batelco.facades.payment.dto.InitPaymentData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

public class InitPaymentRequestPopulator {

//implements Populator<CartModel, InitPaymentData>{

	/*private ConfigProviderService configProviderService;
	public static final String PAYMENT_CHANNEL_CFG_KEY="payment.channel";
	public static final String PAYMENT_USERNAME_CFG_KEY="payment.username";
	public static final String PAYMENT_PASSWORD_CFG_KEY="payment.password";
	public static final String PAYMENT_SOURCE_CFG_KEY="payment.paymentsource";
	
	
	@Override
	public void populate(CartModel source, InitPaymentData target) throws ConversionException {
		// TODO Auto-generated method stub
		
		target.setCardType(source.getPaymentMode().getCode());
		target.setChannel(getChannel());
		target.setIsLoggedIn("true");
		target.setUsername(getUsername());
		target.setPassword(getPassword());
		
		//target.setPaymentConfig(paymentConfig);
		//target.setPaymentId(paymentId);
		//target.setPaymentMode(paymentMode);
		target.setPaymentSource(getPaymentSource());
		//target.setPaymentTotalAmount(source.getTotalPrice());
		//target.setPaymentType(paymentType);
		//target.setRedirectErrorURL(redirectErrorURL);
		//target.setRedirectURL(redirectURL);
		target.setTransUniqueID(source.getCode());
		
		//target.setCustomerId(customerId);
		//target.getCustomerIdType()
		//target.setPaymentCart(paymentCart);
		//target.setCustomerName(customerName);
		
	}
	
	private static String getChannel() {
		
		 return configProviderService.<String>get(PAYMENT_CHANNEL_CFG_KEY)
		        .conversion(value -> value)
		        .validateThat(StringUtils::isNotEmpty)
		        .onInvalid(throwInvalidConfigException())
		        .onMissing(throwMissingConfigException())
		        .convert();
		
	}
	
	private static String getUsername() {
		
		 return configProviderService.<String>get(PAYMENT_USERNAME_CFG_KEY)
		        .conversion(value -> value)
		        .validateThat(StringUtils::isNotEmpty)
		        .onInvalid(throwInvalidConfigException())
		        .onMissing(throwMissingConfigException())
		        .convert();
	}
	
	private static String getPassword() {
		
		 return configProviderService.<String>get(PAYMENT_PASSWORD_CFG_KEY)
		        .conversion(value -> value)
		        .validateThat(StringUtils::isNotEmpty)
		        .onInvalid(throwInvalidConfigException())
		        .onMissing(throwMissingConfigException())
		        .convert();
	}


	private static String getPaymentSource() {
		
		 return configProviderService.<String>get(PAYMENT_SOURCE_CFG_KEY)
		        .conversion(value -> value)
		        .validateThat(StringUtils::isNotEmpty)
		        .onInvalid(throwInvalidConfigException())
		        .onMissing(throwMissingConfigException())
		        .convert();
	}*/
	
}
