package bt.batelco.facades.payment.populators;

import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.order.payment.PaymentModeModel;
import de.hybris.platform.paymentstandard.model.StandardPaymentModeModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import bt.batelco.facades.payment.data.PaymentModeData;

import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

/**
 * This populator will populate the {@link PaymentModeData} from the {@link PaymentModeModel}.
 */
public class PaymentModeDataPopulator 

implements Populator<PaymentModeModel, PaymentModeData> {
  @Override
  public void populate(PaymentModeModel source, PaymentModeData target) throws ConversionException {
    validateParameterNotNullStandardMessage("source", source);
    validateParameterNotNullStandardMessage("target", target);

    target.setCode(source.getCode());
    target.setName(source.getName());
    target.setDescription(source.getDescription());

    populatePaymentTypeIdentifier(source, target);
  }

  private void populatePaymentTypeIdentifier(PaymentModeModel source, PaymentModeData target) {
    if (source instanceof StandardPaymentModeModel) {
      target.setPaymentType(((StandardPaymentModeModel) source).getPaymentTypeId());
    }
  }
}
