package bt.batelco.facades.payment.populators;

import de.hybris.platform.b2ctelcofacades.converters.populator.TmaProductSpecCharacteristicValuePopulator;
import de.hybris.platform.b2ctelcofacades.data.TmaProductSpecCharacteristicValueData;
import de.hybris.platform.b2ctelcoservices.model.TmaProductSpecCharacteristicValueModel;
import de.hybris.platform.converters.Populator;

public class BatelcoTmaProductSpecCharacteristicValuePopulator extends TmaProductSpecCharacteristicValuePopulator
		implements Populator<TmaProductSpecCharacteristicValueModel, TmaProductSpecCharacteristicValueData> {

	@Override
	public void populate(TmaProductSpecCharacteristicValueModel source, TmaProductSpecCharacteristicValueData target) {
		// TODO Auto-generated method stub
		super.populate(source, target);
		target.setProductSpecificCharacteristicId(source.getProductSpecCharacteristic().getId());
		//target.getProductSpecificCharacteristicId(source.getProductSpecCharacteristic().getId());
		System.out.println("its working now --- " + target.getProductSpecificCharacteristicId());
	}

	
}
