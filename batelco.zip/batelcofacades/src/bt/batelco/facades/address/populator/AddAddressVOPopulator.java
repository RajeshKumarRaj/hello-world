package bt.batelco.facades.address.populator;

import bt.batelco.integration.bss.address.vo.AddAddressVO;
import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

public class AddAddressVOPopulator implements Populator<RegisterData, AddAddressVO> {

	@Override
	public void populate(RegisterData source, AddAddressVO target) throws ConversionException {
		//target.setAccountId(source.getAccountId());
		target.setGisAddressId(source.getGisAddressId());
		target.setFlat(source.getFlat());
		target.setBuilding(source.getBuilding());
		target.setRoad(source.getRoad());
		target.setBlock(source.getBlock());
		target.setBuildingName(source.getBuildingName());
		target.setBuildingCharacter("C");
		//target.setBuildingCharacter(source.getBuildingCharacter());
		//target.setSource(source.getSource());
		//target.setAddressStatus(source.getAddressStatus());
	}

}
