package bt.batelco.facades.cart;

import de.hybris.platform.commercefacades.order.CartFacade;
import de.hybris.platform.commercefacades.order.data.CartData;
import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.order.AbstractOrderEntryModel;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * {@link CartFacade} Batelco specific implementation
 */
public interface BatelcoCartFacade extends CartFacade {

  /**
   * Retrieves the acquisition form for the given entry.
   *
   * @param entry the entry
   * @return the acquisition form
   */
  MediaModel getAcquisitionForm(AbstractOrderEntryModel entry);

  /**
   * Determines if the cart has at least one entry with acquisition form.
   *
   * @return {@code true} if the cart has at least one entry with acquisition form, {@code false} otherwise
   */
  boolean hasEntryWithAcquisitionForm();

  /**
   * Retrieves a map containing info about the group and the quantity of its entries
   *
   * @param cart        current cart
   * @param groupNumber group for which we retrieve the entries
   * @return {@link Map} containing the entry number and the corresponding quantity
   */
  Map<Integer, Long> getEntriesFromGroup(CartData cart, int groupNumber);

  /**
   * Check if the revert quantity update was done successfully
   *
   * @param entries entries to be checked
   * @return {@code true} if the operation was successfully, {@code false} otherwise
   */
  boolean checkRevertQuantityUpdate(Map<Integer, Long> entries);

  /**
   * Determines if the cart has all the required documents.
   *
   * @return {@code true} if the cart has all the required documents, {@code false} otherwise
   */
  boolean hasAllRequiredDocuments();

  /**
   * Determines if the cart has all the entries with acquisition form configured.
   *
   * @return {@code true} if valid, {@code false} otherwise
   */
  boolean isAcquisitionFormConfiguredOnEntries();
  
  /**Gets the cart entry based on entry number.
   * AJ00482484 : Added for Acquisition Form Change
   * @param entryNumber
   * @return
   */
  AbstractOrderEntryModel getCartEntry(int entryNumber);
  
  InputStream getStreamForMedia(MediaModel mediaModel);
}
