package bt.batelco.facades.exception;

public class ConsentAlreadySignedFacadeException extends FacadeException {
  public ConsentAlreadySignedFacadeException(String message) {
    super(message);
  }

  public ConsentAlreadySignedFacadeException(String message, Throwable cause) {
    super(message, cause);
  }

  public ConsentAlreadySignedFacadeException(Throwable cause) {
    super(cause);
  }
}
