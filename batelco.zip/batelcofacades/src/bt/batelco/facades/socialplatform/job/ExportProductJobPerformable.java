package bt.batelco.facades.socialplatform.job;

import com.batelco.core.jobs.model.ExportProductCronJobModel;
import de.hybris.platform.cms2.model.site.CMSSiteModel;
import de.hybris.platform.commerceservices.impersonation.ImpersonationContext;
import de.hybris.platform.commerceservices.impersonation.ImpersonationService;
import de.hybris.platform.cronjob.enums.CronJobResult;
import de.hybris.platform.cronjob.enums.CronJobStatus;
import de.hybris.platform.servicelayer.cronjob.AbstractJobPerformable;
import de.hybris.platform.servicelayer.cronjob.PerformResult;
import de.hybris.platform.site.BaseSiteService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import java.util.Collections;
import bt.batelco.facades.product.BatelcoExportProductFacade;

public class ExportProductJobPerformable extends AbstractJobPerformable<ExportProductCronJobModel> {

    private static final Logger LOG = Logger.getLogger(ExportProductJobPerformable.class);
    private static final String BASESITE_UID ="batelco";

    private BatelcoExportProductFacade batelcoExportProductFacade;
    private BaseSiteService baseSiteService;
    private ImpersonationService impersonationService;

    /**
     *  Generates product feed for facebook
     * @param exportProductCronJobModel
     *          ExportProductCronJobModel
     * @return
     *      returns PerformResult
     */
    @Override
    public PerformResult perform(ExportProductCronJobModel exportProductCronJobModel) {

        try{
            final ImpersonationContext context = getImpersonationContext(exportProductCronJobModel);
            getImpersonationService().executeInContext(context, () -> {
                getBatelcoExportProductFacade().performProductExport(exportProductCronJobModel.getFacebookFeed(),exportProductCronJobModel.getCatalogVersion());
                return new PerformResult(CronJobResult.SUCCESS, CronJobStatus.FINISHED);
            });
        }catch(Exception e){
            LOG.error("Exception while exporting the Product feed for FaceBook: ",e);
            return new PerformResult(CronJobResult.ERROR, CronJobStatus.ABORTED);
        }

        return new PerformResult(CronJobResult.SUCCESS, CronJobStatus.FINISHED);
    }

    /**
     * Populate the ImpersonationContext
     * @param exportProductCronJobModel
     *          ExportProductCronJobModel
     * @return
     *      returns the ImpersonationContext
     */
    private ImpersonationContext getImpersonationContext(ExportProductCronJobModel exportProductCronJobModel) {
        final ImpersonationContext context = new ImpersonationContext();
        CMSSiteModel cmsSiteModel = (CMSSiteModel) getBaseSiteService().getBaseSiteForUID(BASESITE_UID);
        context.setSite(cmsSiteModel);
        cmsSiteModel.getStores().stream().findFirst().ifPresent(baseStore -> context.setCurrency(baseStore.getDefaultCurrency()));
        context.setCatalogVersions(Collections.singletonList(exportProductCronJobModel.getCatalogVersion()));
        context.setUser(exportProductCronJobModel.getSessionUser());
        context.setLanguage(cmsSiteModel.getDefaultLanguage());
        return context;
    }

    @Override
    public boolean isAbortable() {
        return true;
    }

    @Required
    public void setBatelcoExportProductFacade(BatelcoExportProductFacade batelcoExportProductFacade) {
        this.batelcoExportProductFacade = batelcoExportProductFacade;
    }

    public BatelcoExportProductFacade getBatelcoExportProductFacade() {
        return batelcoExportProductFacade;
    }

    public ImpersonationService getImpersonationService()
    {
        return impersonationService;
    }

    @Required
    public void setImpersonationService(final ImpersonationService impersonationService)
    {
        this.impersonationService = impersonationService;
    }

    public BaseSiteService getBaseSiteService() {
        return baseSiteService;
    }

    @Required
    public void setBaseSiteService(BaseSiteService baseSiteService) {
        this.baseSiteService = baseSiteService;
    }
}
