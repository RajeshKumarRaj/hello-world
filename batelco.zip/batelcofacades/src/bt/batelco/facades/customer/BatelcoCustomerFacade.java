package bt.batelco.facades.customer;

import java.util.Map;

import de.hybris.platform.commercefacades.customer.CustomerFacade;

/**
 * Facade to perform various customer related operations
 */
public interface BatelcoCustomerFacade extends CustomerFacade {

  /**
   * Update customer when email confirmation is done.
   *
   * @param customerId customerId
   */
  void updateCustomerRegistration(final String customerId);

  /**
   * Check if user is unregistered
   *
   * @param uid customer uid
   * @return true when is unregistered
   * @throws bt.batelco.facades.exception.InvalidCustomerFacadeException - when user is not found
   */
  boolean isRegistrationNotCompleted(final String uid);
  
  public String getIdType(String customerId);
  
  /**
   * Check if user exist for given CPR
   * @param cpr
   * @return
   */
  boolean isAccountExistForCPR(String cpr);
  
  /**
   * Validates address from GIS service
   * @param addressParams
   * @return
   */
  String validateAddress(Map<String, String> addressParams);
  /**
   * Checks whether the customer exist in Siebel system
   * @param idType
   * @param id
   * @return accountNumber
   */
  String getSiebelCustomer(String idType, String id);
  
}
