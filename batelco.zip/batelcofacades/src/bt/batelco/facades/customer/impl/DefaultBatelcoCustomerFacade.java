package bt.batelco.facades.customer.impl;

import com.iquest.config.service.ConfigProviderService;

import de.hybris.platform.b2ctelcofacades.user.impl.TmaDefaultCustomerFacade;
import de.hybris.platform.commercefacades.user.data.CustomerData;
import de.hybris.platform.commercefacades.user.data.RegisterData;
import de.hybris.platform.commerceservices.customer.DuplicateUidException;
import de.hybris.platform.commerceservices.enums.CustomerType;
import de.hybris.platform.core.model.user.AddressModel;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.servicelayer.exceptions.UnknownIdentifierException;
import de.hybris.platform.servicelayer.user.UserService;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.core.convert.converter.Converter;

import bt.batelco.core.customer.service.BatelcoCustomerAccountService;
import bt.batelco.core.enums.CustomerIdType;
import bt.batelco.integration.bss.account.service.AddUpdateAccountService;
import bt.batelco.integration.bss.account.vo.AccountVO;
import bt.batelco.integration.bss.account.vo.AddUpdateAccountPayload;
import bt.batelco.integration.bss.address.service.AddAddressService;
import bt.batelco.integration.bss.address.service.ProcessAddressService;
import bt.batelco.integration.bss.address.vo.AddAddressPayload;
import bt.batelco.integration.bss.address.vo.AddAddressVO;
import bt.batelco.integration.bss.address.vo.ValidateAddressVO;
import bt.batelco.integration.bss.customer.service.QueryCustomerService;
import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoPayload;
import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoVO;
import bt.batelco.facades.account.populator.AccountVOPopulator;
import bt.batelco.facades.constants.BatelcoFacadesConstants;
import bt.batelco.facades.customer.BatelcoCustomerFacade;
import bt.batelco.facades.exception.InvalidCustomerFacadeException;

import static com.iquest.config.provider.IncorrectConfigurationActions.useDefault;
import static de.hybris.platform.servicelayer.util.ServicesUtil.validateParameterNotNullStandardMessage;

import java.util.Map;
import java.util.concurrent.TimeoutException;

/**
 * Implementation of customer facade. It implements specific operations around customers
 * Override due to new CPR/CR ID field and defaultShipmentAddress in register method;
 * added new methods for confirm registration
 */
public class DefaultBatelcoCustomerFacade extends TmaDefaultCustomerFacade implements BatelcoCustomerFacade {

  private static final Logger LOG = LoggerFactory.getLogger(DefaultBatelcoCustomerFacade.class);
  private static final String DEFAULT_COUNTRY_ISO_CODE = "default.country.isoCode";
  private static final String BAHRAIN_COUNTRY_CODE = "BH";

  private Converter<RegisterData, AddressModel> batelcoRegisterAddressReverseConverter;
  private BatelcoCustomerAccountService batelcoCustomerAccountService;
  private ConfigProviderService configProviderService;
  private UserService userService;
  
  private ProcessAddressService processAddressService;
  private AddAddressService addAddressService;
  private AddUpdateAccountService addUpdateAccountService;
  private QueryCustomerService queryCustomerService;
  
  private Converter<RegisterData, AccountVO> accountVOConverter;
  private Converter<RegisterData, AddAddressVO> addAddressVOConverter;

  @Override
  public void register(final RegisterData registerData) throws DuplicateUidException {
    validateParameterNotNullStandardMessage("registerData", registerData);

    final CustomerModel newCustomer = getModelService().create(CustomerModel.class);
    newCustomer.setName(getCustomerNameStrategy().getName(registerData.getFirstName(), registerData.getLastName()));
    newCustomer.setLastName(registerData.getLastName());
    newCustomer.setFirstName(registerData.getFirstName());

    setUidForRegister(registerData, newCustomer);
    newCustomer.setDefaultShipmentAddress(createAddress(newCustomer, registerData));
    if(registerData.getIdType().equals(CustomerIdType.CPR)) {
    	newCustomer.setIdType(CustomerIdType.CPR);
    } else {
    	newCustomer.setIdType(CustomerIdType.CR_ID);
    }
    newCustomer.setCprId(registerData.getCprId());
    newCustomer.setSessionLanguage(getCommonI18NService().getCurrentLanguage());
    newCustomer.setSessionCurrency(getCommonI18NService().getCurrentCurrency());
    newCustomer.setType(CustomerType.UNREGISTERED);
    newCustomer.setLoginDisabled(Boolean.TRUE);
    batelcoCustomerAccountService.register(newCustomer, registerData.getPassword());
    // share data to Siebel system & update accountId from response in customer table
    if(registerData.getIdType().equals(CustomerIdType.CPR.name())) {
    	String accountId = registerData.getAccountNumber();
    	if(StringUtils.isBlank(accountId)) {
    		accountId = updateCustomerInSiebel(registerData);
    	}
    	updateCustomer(registerData, accountId);
    }
  }

  private AddressModel createAddress(CustomerModel newCustomer, RegisterData registerData) {
    AddressModel addressModel = batelcoRegisterAddressReverseConverter.convert(registerData);
    addressModel.setOwner(newCustomer);
    return addressModel;
  }

  @Required
  public void setBatelcoRegisterAddressReverseConverter(
      Converter<RegisterData, AddressModel> batelcoRegisterAddressReverseConverter) {
    this.batelcoRegisterAddressReverseConverter = batelcoRegisterAddressReverseConverter;
  }

  @Override
  public void updateCustomerRegistration(String customerId) {
    CustomerModel customerModel = batelcoCustomerAccountService.findCustomerModelByCustomerId(customerId);
    customerModel.setType(CustomerType.REGISTERED);
    customerModel.setLoginDisabled(Boolean.FALSE);

    getModelService().save(customerModel);
  }

  @Override
  public void updateProfile(final CustomerData customerData) throws DuplicateUidException {
    validateParameterNotNullStandardMessage("customerData", customerData);

    final String name = getCustomerNameStrategy().getName(customerData.getFirstName(), customerData.getLastName());
    final CustomerModel customer = getCurrentSessionCustomer();
    customer.setOriginalUid(customerData.getDisplayUid());
    customer.setUid(customerData.getUid().trim());
    customer.setName(name);
    customer.setFirstName(customerData.getFirstName());
    customer.setLastName(customerData.getLastName());
    customer.setCprId(customerData.getCprId());
    if (customer.getDefaultShipmentAddress() != null) {
      customer.getDefaultShipmentAddress().setPhone1(customerData.getDefaultShippingAddress().getPhone());
    } else {
      final AddressModel addressModel = createAddressModel(customerData);
      addressModel.setOwner(customer);
      customer.setDefaultShipmentAddress(addressModel);
    }

    batelcoCustomerAccountService.updateProfile(customer);
    getModelService().save(customer.getDefaultShipmentAddress());
  }

  /**
   * Create address when user updates his profile and does not have a default shipping address.
   * Default fields for address filled
   */
  private AddressModel createAddressModel(CustomerData customerData) {
    final AddressModel addressModel = getModelService().create(AddressModel.class);
    addressModel.setFirstname(customerData.getFirstName());
    addressModel.setLastname(customerData.getLastName());
    addressModel.setPhone1(customerData.getDefaultShippingAddress().getPhone());
    addressModel.setShippingAddress(Boolean.TRUE);
    addressModel.setVisibleInAddressBook(Boolean.TRUE);

    final String defaultCountry = configProviderService.<String>get(DEFAULT_COUNTRY_ISO_CODE)
        .conversion(source -> source).onMissing(useDefault(BAHRAIN_COUNTRY_CODE)).convert();

    addressModel.setCountry(getCommonI18NService().getCountry(defaultCountry));
    return addressModel;
  }

  @Override
  public boolean isRegistrationNotCompleted(String uid) {
    UserModel userModel;
    try {
      userModel = getUserService().getUserForUID(uid);
    } catch (UnknownIdentifierException ex) {
      throw new InvalidCustomerFacadeException(ex);
    }

    if (userModel instanceof CustomerModel) {
      CustomerModel customerModel = (CustomerModel) userModel;
      return customerModel.isLoginDisabled() && CustomerType.UNREGISTERED.equals(customerModel.getType());
    }

    return false;
  }
  
  @Override
  public String getIdType(String customerId) {
	  String idType = "";
	  CustomerModel customerModel = batelcoCustomerAccountService.findCustomerModelByCustomerId(customerId);
	  idType = customerModel.getIdType() == CustomerIdType.CPR ? "CPR" : "CR";
	  return idType;
  }

  @Required
  public void setBatelcoCustomerAccountService(BatelcoCustomerAccountService batelcoCustomerAccountService) {
    this.batelcoCustomerAccountService = batelcoCustomerAccountService;
  }

  @Required
  public void setConfigProviderService(ConfigProviderService configProviderService) {
    this.configProviderService = configProviderService;
  }
  
  public ProcessAddressService getProcessAddressService() {
		return processAddressService;
	}
	
	public void setProcessAddressService(ProcessAddressService processAddressService) {
		this.processAddressService = processAddressService;
	}
	
	public AddAddressService getAddAddressService() {
		return addAddressService;
	}

	public void setAddAddressService(AddAddressService addAddressService) {
		this.addAddressService = addAddressService;
	}

	public AddUpdateAccountService getAddUpdateAccountService() {
		return addUpdateAccountService;
	}

	public void setAddUpdateAccountService(AddUpdateAccountService addUpdateAccountService) {
		this.addUpdateAccountService = addUpdateAccountService;
	}
	
	public QueryCustomerService getQueryCustomerService() {
		return queryCustomerService;
	}

	public void setQueryCustomerService(QueryCustomerService queryCustomerService) {
		this.queryCustomerService = queryCustomerService;
	}

	public Converter<RegisterData, AccountVO> getAccountVOConverter() {
		return accountVOConverter;
	}

	public void setAccountVOConverter(Converter<RegisterData, AccountVO> accountVOConverter) {
		this.accountVOConverter = accountVOConverter;
	}
	
	public Converter<RegisterData, AddAddressVO> getAddAddressVOConverter() {
		return addAddressVOConverter;
	}

	public void setAddAddressVOConverter(Converter<RegisterData, AddAddressVO> addAddressVOConverter) {
		this.addAddressVOConverter = addAddressVOConverter;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	@Override
	public boolean isAccountExistForCPR(String cpr) {
		return batelcoCustomerAccountService.isAccountExistForCPR(cpr);
	}

	@Override
	public String validateAddress(Map<String, String> addressParams) {
		ValidateAddressVO addressVO = new ValidateAddressVO();
		addressVO.setFlat(addressParams.get(BatelcoFacadesConstants.FLAT));
		addressVO.setBuilding(addressParams.get(BatelcoFacadesConstants.BUILDING));
		addressVO.setRoad(addressParams.get(BatelcoFacadesConstants.ROAD));
		addressVO.setBlock(addressParams.get(BatelcoFacadesConstants.BLOCK));
		return getProcessAddressService().validateAddress(addressVO).getGisAddressId();
	}
	
	@Override
	public String getSiebelCustomer(String idType, String id) {
		String accountNumber = "";
		QueryCustomerInfoVO customerVO = new QueryCustomerInfoVO ();
		customerVO.setIdentificationType(idType);
		customerVO.setIdentificationNumber(id);
		QueryCustomerInfoPayload queryCustomerPayload = getQueryCustomerService().getCustomerInfo(customerVO);
		 if(queryCustomerPayload != null) {
			 accountNumber = queryCustomerPayload.getAccountNumber();
		 }
		return accountNumber;
	}
	
	private String addUpdateAccount(final RegisterData registerData) {
		AccountVO customerAccount = new AccountVO();
		customerAccount = accountVOConverter.convert(registerData);
		AddUpdateAccountPayload payload = getAddUpdateAccountService().addUpdateAccount(customerAccount);
		LOG.info("Data shared to Siebel system - " + customerAccount);
		LOG.info("Response received from Siebel system - " + payload);
		
		return payload.getAccountId();
	}
	
	private String addAddress(final RegisterData registerData) {
		AddAddressVO address = new AddAddressVO();
		address = getAddAddressVOConverter().convert(registerData);
		AddAddressPayload addressPayload = getAddAddressService().addAddress(address);
		LOG.info("Address shared to Siebel system - " + address);
		LOG.info("Response received for AddAddress from Siebel system - " + addressPayload);
		return addressPayload.getSiebelRowId();
	}
	
	private String updateCustomerInSiebel(RegisterData registerData) {
		String accountId = null;
		String rowId = null;
		try {
			accountId = addUpdateAccount(registerData);
			if(!StringUtils.isBlank(accountId)) {
				rowId = addAddress(registerData); 
			}
		} catch(Exception te) {
			try {
				accountId = addUpdateAccount(registerData);
				if(!StringUtils.isBlank(accountId)) {
					rowId = addAddress(registerData); 
				}
			} catch(Exception ate) {
				AccountVO customerAccount = new AccountVO();
				customerAccount = accountVOConverter.convert(registerData);
				// TODO - Send email to customer service to update the data manually
				LOG.info("Email sent to customer service to update the user manually - " + customerAccount);
			}
		}
		return accountId;
	  }
	private void updateCustomer(RegisterData registerData, String accountId) {
		CustomerModel customer = (CustomerModel) getUserService().getUserForUID(registerData.getLogin().toLowerCase());
		customer.setAccountId(accountId);
		getModelService().save(customer);
	}
}
