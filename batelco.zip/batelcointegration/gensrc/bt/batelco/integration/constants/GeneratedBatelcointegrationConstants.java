/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 23, 2020 8:44:23 PM                     ---
 * ----------------------------------------------------------------
 */
package bt.batelco.integration.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBatelcointegrationConstants
{
	public static final String EXTENSIONNAME = "batelcointegration";
	
	protected GeneratedBatelcointegrationConstants()
	{
		// private constructor
	}
	
	
}
