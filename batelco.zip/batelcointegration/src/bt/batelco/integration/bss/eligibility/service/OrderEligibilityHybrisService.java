package bt.batelco.integration.bss.eligibility.service;

public interface OrderEligibilityHybrisService {
	
	String checkEligibility(String serviceId, String orderReason);

}
