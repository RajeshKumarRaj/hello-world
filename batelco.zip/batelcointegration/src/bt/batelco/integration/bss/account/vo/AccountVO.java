package bt.batelco.integration.bss.account.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AccountVO {
	
	private String email;
	private String firstName;
	private String lastName;
	private String idType;
	private String cprId;
	private String dob;
	private String phone;
	private String accountId;
	
	// Address fields
	private String block;
    private String city;
    private String gisAddressId;
    private String addressId;
    private String road; 
    private String country;
    private String zipCode;
    private String flat; 
    private String buildingName;
    //private String buildingCharacter;
    //private String source;
    private String building; 
    
    // Consent fields
    private String consentGiven;
    private String consentTemplateId;
    private String consentTemplateVersion;
    
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public String getCprId() {
		return cprId;
	}
	public void setCprId(String cprId) {
		this.cprId = cprId;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getBlock() {
		return block;
	}
	public void setBlock(String block) {
		this.block = block;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGisAddressId() {
		return gisAddressId;
	}
	public void setGisAddressId(String gisAddressId) {
		this.gisAddressId = gisAddressId;
	}
	public String getAddressId() {
		return addressId;
	}
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	public String getRoad() {
		return road;
	}
	public void setRoad(String road) {
		this.road = road;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getFlat() {
		return flat;
	}
	public void setFlat(String flat) {
		this.flat = flat;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getConsentGiven() {
		return consentGiven;
	}
	public void setConsentGiven(String consentGiven) {
		this.consentGiven = consentGiven;
	}
	public String getConsentTemplateId() {
		return consentTemplateId;
	}
	public void setConsentTemplateId(String consentTemplateId) {
		this.consentTemplateId = consentTemplateId;
	}
	public String getConsentTemplateVersion() {
		return consentTemplateVersion;
	}
	public void setConsentTemplateVersion(String consentTemplateVersion) {
		this.consentTemplateVersion = consentTemplateVersion;
	}
	
	@Override
	public String toString() {
		return "AccountVO [email=" + email + ", firstName=" + firstName + ", lastName=" + lastName + ", idType="
				+ idType + ", cprId=" + cprId + ", dob=" + dob + ", phone=" + phone + ", accountId=" + accountId
				+ ", block=" + block + ", city=" + city + ", gisAddressId=" + gisAddressId + ", addressId=" + addressId
				+ ", road=" + road + ", country=" + country + ", zipCode=" + zipCode + ", flat=" + flat
				+ ", buildingName=" + buildingName + ", building=" + building + ", consentGiven=" + consentGiven
				+ ", consentTemplateId=" + consentTemplateId + ", consentTemplateVersion=" + consentTemplateVersion
				+ "]";
	}
	
	public static void main(String[] ar) {
		String date = "12/09/2002";
	    String oldFormat = "dd/MM/yyyy";
	    String newFormat = "yyyy-MM-dd'T'HH:mm:ss";
	    SimpleDateFormat sdf = new SimpleDateFormat(oldFormat);
	    try {
	        Date newDate = sdf.parse(date);
	        sdf.applyPattern(newFormat);
	        System.out.println(sdf.format(newDate));
	    } catch (ParseException e) {
	        e.printStackTrace();
	    }		        
	}
    
}
