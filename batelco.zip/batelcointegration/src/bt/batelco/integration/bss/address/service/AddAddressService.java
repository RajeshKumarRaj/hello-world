package bt.batelco.integration.bss.address.service;

import bt.batelco.integration.bss.address.vo.AddAddressPayload;
import bt.batelco.integration.bss.address.vo.AddAddressVO;

public interface AddAddressService {
	
	public AddAddressPayload addAddress(AddAddressVO address);

}
