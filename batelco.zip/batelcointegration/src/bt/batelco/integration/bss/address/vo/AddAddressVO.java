package bt.batelco.integration.bss.address.vo;

public class AddAddressVO {
	    //protected String exchange;
	    //protected String mediaType;
	//protected String domain;
	//protected String sitePhoneNumber;
	//protected String legalFlag;
	//protected String landmark;
	    private String block;// blockArabicLine2;
	    private String city;
	    private String gisAddressId;
	    private String addressId;
	    private String road; //roadArabicLine1;
	    private String country;
	    private String flat; //flatEnglishLine1;
	    private String buildingName;
	    private String buildingCharacter;
	    private String source;
	    private String accountId;
	    private String building; //buildingEnglishLine2;
	    //protected String shippingFlag;
	    //protected String action;
	    //protected String billingFlag;
	    protected String addressStatus;
	    //protected String category;
	    //protected String roadName;
		public String getBlock() {
			return block;
		}
		public void setBlock(String block) {
			this.block = block;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getGisAddressId() {
			return gisAddressId;
		}
		public void setGisAddressId(String gisAddressId) {
			this.gisAddressId = gisAddressId;
		}
		public String getAddressId() {
			return addressId;
		}
		public void setAddressId(String addressId) {
			this.addressId = addressId;
		}
		public String getRoad() {
			return road;
		}
		public void setRoad(String road) {
			this.road = road;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getFlat() {
			return flat;
		}
		public void setFlat(String flat) {
			this.flat = flat;
		}
		public String getBuildingName() {
			return buildingName;
		}
		public void setBuildingName(String buildingName) {
			this.buildingName = buildingName;
		}
		public String getBuildingCharacter() {
			return buildingCharacter;
		}
		public void setBuildingCharacter(String buildingCharacter) {
			this.buildingCharacter = buildingCharacter;
		}
		public String getSource() {
			return source;
		}
		public void setSource(String source) {
			this.source = source;
		}
		public String getAccountId() {
			return accountId;
		}
		public void setAccountId(String accountId) {
			this.accountId = accountId;
		}
		public String getBuilding() {
			return building;
		}
		public void setBuilding(String building) {
			this.building = building;
		}
		public String getAddressStatus() {
			return addressStatus;
		}
		public void setAddressStatus(String addressStatus) {
			this.addressStatus = addressStatus;
		}
	    
	    
}

