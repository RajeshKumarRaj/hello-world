package bt.batelco.integration.bss.address.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.batelco.wsdl.processaddress.ValidateAddressResponseMessage;

import bt.batelco.integration.bss.address.helper.ValidateAddressHelper;
import bt.batelco.integration.bss.address.service.ProcessAddressService;
import bt.batelco.integration.bss.address.vo.ValidateAddressPayload;
import bt.batelco.integration.bss.address.vo.ValidateAddressVO;
import bt.batelco.integration.common.CommonHelper;
import de.hybris.platform.webservicescommons.errors.exceptions.WebserviceException;

public class DefaultProcessAddressService implements ProcessAddressService {
	
	private String processAddressWsdl;
	private static final Logger LOG = LoggerFactory.getLogger(DefaultProcessAddressService.class);


	@Override
	public ValidateAddressPayload validateAddress(ValidateAddressVO address) {
		ValidateAddressPayload payload = null;
		try {
		payload = new ValidateAddressPayload();
		//TODO populate payload with proper errors for failures
		com.batelco.wsdl.processaddress.ProcessAddressBindingQSService service = 
				new com.batelco.wsdl.processaddress.ProcessAddressBindingQSService(CommonHelper.getURL(processAddressWsdl));
		ValidateAddressResponseMessage response = service.getProcessAddressBindingQSPort().validateAddress(ValidateAddressHelper.getRequestMessage(address));

		LOG.info("Response - " + response);
		payload = ValidateAddressHelper.getResponsePayload(response);
		LOG.info("Payload - " + payload);
		} 
		catch(WebserviceException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return payload;
	}

	public String getProcessAddressWsdl() {
		//processAddressWsdl = "http://localhost:8088//mockProcessAddressBinding?wsdl";
		return processAddressWsdl;
	}

	public void setProcessAddressWsdl(String processAddressWsdl) {
		this.processAddressWsdl = processAddressWsdl;
	}

}
