package bt.batelco.integration.bss.customer.vo;

import bt.batelco.integration.bss.vo.BssPayload;

public class QueryCustomerInfoPayload extends BssPayload {
	private String accountNumber;
	private String accountClass;
	private String identificationNumber;
	private String identificationType;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getAccountClass() {
		return accountClass;
	}
	public void setAccountClass(String accountClass) {
		this.accountClass = accountClass;
	}
	
	public String getIdentificationNumber() {
		return identificationNumber;
	}
	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}
	
	public String getIdentificationType() {
		return identificationType;
	}
	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}
	
	@Override
	public String toString() {
		return "QueryCustomerInfoPayload [accountNumber=" + accountNumber + ", accountClass=" + accountClass
				+ ", identificationNumber=" + identificationNumber + ", identificationType=" + identificationType + "]";
	}
	
}
