package bt.batelco.integration.bss.customer.helper;

import java.util.List;

import com.batelco.wsdl.querycustomerinformation.QueryAccountDetailsRequestMessage;
import com.batelco.wsdl.querycustomerinformation.QueryAccountDetailsResponseMessage;
import com.batelco.xsd.common.ResponseHeaderType;
import com.batelco.xsd.querycustomerinformation.AccountDetailsType;
import com.batelco.xsd.querycustomerinformation.QueryAccountDetailsRequestType;
import com.batelco.xsd.querycustomerinformation.QueryAccountDetailsResponseType;
import com.batelco.xsd.querycustomerinformation.QueryCriteriaType;

import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoPayload;
import bt.batelco.integration.bss.customer.vo.QueryCustomerInfoVO;
import bt.batelco.integration.common.CommonHelper;

public class QueryCustomerInfoHelper {
	
	public static QueryAccountDetailsRequestMessage createRequest(QueryCustomerInfoVO customerVO) {
		QueryAccountDetailsRequestMessage request = new QueryAccountDetailsRequestMessage();
		request.setRequestHeader(CommonHelper.getRequestHeader());
		request.setPayload(createRequestBody(customerVO));
		return request;
	}
	
	public static QueryAccountDetailsRequestType createRequestBody(QueryCustomerInfoVO customerVO) {
		QueryAccountDetailsRequestType queryAccountDetailsRequest = new QueryAccountDetailsRequestType();
		
		List<QueryCriteriaType> queryCriteriaList = queryAccountDetailsRequest.getQueryCriteria();
		
		QueryCriteriaType queryCriteria = new QueryCriteriaType();
		queryCriteria.setIdentificationType(customerVO.getIdentificationType());
		queryCriteria.setIdentificationNumber(customerVO.getIdentificationNumber());
		
		queryCriteriaList.add(queryCriteria);
		
		return queryAccountDetailsRequest;
	}
	
	public static QueryCustomerInfoPayload getResponsePayload(QueryAccountDetailsResponseMessage response) {
		QueryCustomerInfoPayload responsePayload = null;
		if(response != null) {
			if(response.getPayload() != null) {
				CommonHelper.updateResponseHeader(response.getResponseHeader(), responsePayload);
				QueryAccountDetailsResponseType responseBody = response.getPayload();
				if(responseBody.getAccountDetails() != null) {
					responsePayload = createResponsePayload(responseBody);
				}
			}
		}
		return responsePayload;
	}
	
	public static QueryCustomerInfoPayload createResponsePayload(QueryAccountDetailsResponseType responseBody) {
		QueryCustomerInfoPayload responsePayload = new QueryCustomerInfoPayload();
		List<AccountDetailsType> accountDetailsList = responseBody.getAccountDetails();
		
		AccountDetailsType accountDetails = accountDetailsList.get(0);
		//for(AccountDetailsType accountDetails : accountDetailsList) {
			responsePayload.setAccountClass(accountDetails.getAccountClass());
			responsePayload.setAccountNumber(accountDetails.getAccountNumber());
			responsePayload.setIdentificationType(accountDetails.getIdentificationType());
			responsePayload.setIdentificationNumber(accountDetails.getIdentificationNumber());
		//}
		return responsePayload;
	}
}
